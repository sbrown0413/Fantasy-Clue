Authors: Summer Brown and Kairi Hoang
CSCI306-C

We changed testAdjacencyLeftEdge because we accidentally had an AssertsTrue on a cell that was not adjacent to the one we chose.

We changed testTargetsWithRoom because we accidentally said a room was a valid target, but it is not.

There was small mistakes in a few of our tests. It was mostly changing the number of cells or targets that we were supposed to be looking for.
As a result, we had to change some of the cells that we were asserting as True as well as add in more tests to see where we were failing.