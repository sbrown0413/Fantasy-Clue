package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;

public class BoardAdjTargetTest {
	// We make the Board static because we can load it one time and 
	// then do all the tests. 
	private static Board board;
	
	@BeforeAll
	public static void setUp() {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");		
		// Initialize will load config files 
		board.initialize();
		// Clear occupied cells
		board.clearOccupiedCells();
	}

	 //Ensure that player does not move around within room
	 //These cells are LIGHT PINK on the planning spreadsheet
	@Test
	public void testAdjacenciesRooms()
	{
		// we want to test a couple of different rooms.
		// First, the dragon's nest that only has a single door but a secret room to hobbit hole
		Set<BoardCell> testList = board.getAdjList(29, 21);
		assertEquals(2, testList.size());
		assertTrue(testList.contains(board.getCell(29, 17)));
		assertTrue(testList.contains(board.getCell(18, 1)));
		
		// now test the waterfall (note not marked since multiple test here)
		testList = board.getAdjList(31, 3);
		assertEquals(2, testList.size());
		assertTrue(testList.contains(board.getCell(29, 6)));
		assertTrue(testList.contains(board.getCell(31, 12)));
		
		// test to make sure non center cell in room has no adjacencies
		testList = board.getAdjList(20, 19);
		assertEquals(0, testList.size());
		
		// one more room, the fairy tree
		testList = board.getAdjList(15, 21);
		assertEquals(3, testList.size());
		assertTrue(testList.contains(board.getCell(9, 19)));
		assertTrue(testList.contains(board.getCell(16, 17)));
		assertTrue(testList.contains(board.getCell(4, 13)));
	}

	
	// Ensure door locations include their rooms and also additional walkways
	// These cells are LIGHT PINK on the planning spreadsheet
	@Test
	public void testAdjacencyDoor()
	{
		Set<BoardCell> testList = board.getAdjList(29, 6);
		assertEquals(3, testList.size());
		assertTrue(testList.contains(board.getCell(28, 6)));
		assertTrue(testList.contains(board.getCell(29, 7)));
		assertTrue(testList.contains(board.getCell(31, 3)));

		testList = board.getAdjList(3, 4);
		assertEquals(4, testList.size());
		assertTrue(testList.contains(board.getCell(3, 5)));
		assertTrue(testList.contains(board.getCell(2, 4)));
		assertTrue(testList.contains(board.getCell(4, 4)));
		assertTrue(testList.contains(board.getCell(3, 2)));
		
		testList = board.getAdjList(3, 16);
		assertEquals(3, testList.size());
		assertTrue(testList.contains(board.getCell(2, 16)));
		assertTrue(testList.contains(board.getCell(4, 16)));
		assertTrue(testList.contains(board.getCell(3, 19)));
	}
	
	// Test a variety of walkway scenarios
	// These tests are DARK PURPLE on the planning spreadsheet
	@Test
	public void testAdjacencyWalkways()
	{
		// Test on bottom edge of board, just one walkway piece
		Set<BoardCell> testList = board.getAdjList(32, 7);
		assertEquals(2, testList.size());
		assertTrue(testList.contains(board.getCell(32, 8)));
		assertTrue(testList.contains(board.getCell(31, 7)));
		
		// Test near a door but not adjacent
		testList = board.getAdjList(4, 5);
		assertEquals(3, testList.size());
		assertTrue(testList.contains(board.getCell(3, 5)));
		assertTrue(testList.contains(board.getCell(5, 5)));
		assertTrue(testList.contains(board.getCell(4, 4)));

		// Test adjacent to walkways
		testList = board.getAdjList(9, 7);
		assertEquals(4, testList.size());
		assertTrue(testList.contains(board.getCell(9, 6)));
		assertTrue(testList.contains(board.getCell(8, 7)));
		assertTrue(testList.contains(board.getCell(10, 7)));
		assertTrue(testList.contains(board.getCell(9, 8)));

		// Test next to closet
		testList = board.getAdjList(20,12);
		assertEquals(3, testList.size());
		assertTrue(testList.contains(board.getCell(21, 12)));
		assertTrue(testList.contains(board.getCell(20, 11)));
		assertTrue(testList.contains(board.getCell(20, 13)));
	
	}
	
	
	// Tests out of room center, 1, 3 and 4
	// These are TEAL BLUE on the planning spreadsheet
	@Test
	public void testTargetsInMushroomHouse() {
		// test a roll of 1
		board.calcTargets(board.getCell(3, 2), 1);
		Set<BoardCell> targets = board.getTargets();

		assertEquals(1, targets.size());
		assertTrue(targets.contains(board.getCell(3, 4)));
		
		// test a roll of 3
		board.calcTargets(board.getCell(3, 2), 3);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(1, 4)));
		assertTrue(targets.contains(board.getCell(4, 5)));	
		assertTrue(targets.contains(board.getCell(5, 4)));
		assertTrue(targets.contains(board.getCell(2, 5)));	
		
		// test a roll of 4
		board.calcTargets(board.getCell(3, 2), 4);
		targets= board.getTargets();
		assertEquals(8, targets.size());
		assertTrue(targets.contains(board.getCell(6, 4)));
		assertTrue(targets.contains(board.getCell(5, 5)));	
		assertTrue(targets.contains(board.getCell(4, 4)));
		assertTrue(targets.contains(board.getCell(1, 5)));	
	}
	
	@Test
	public void testTargetsInHobbitHole() {
		// test a roll of 1
		board.calcTargets(board.getCell(18, 1), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(17, 3)));
		assertTrue(targets.contains(board.getCell(11, 1)));	
		assertTrue(targets.contains(board.getCell(29, 21)));	
		
		// test a roll of 3
		board.calcTargets(board.getCell(18, 1), 3);
		targets= board.getTargets();
		assertEquals(10, targets.size());
		assertTrue(targets.contains(board.getCell(11, 3)));
		assertTrue(targets.contains(board.getCell(10, 2)));	
		assertTrue(targets.contains(board.getCell(18, 4)));
		assertTrue(targets.contains(board.getCell(29, 21)));	
		
		// test a roll of 4
		board.calcTargets(board.getCell(18, 1), 4);
		assertEquals(19, targets.size());
		assertTrue(targets.contains(board.getCell(17, 6)));
		assertTrue(targets.contains(board.getCell(16, 5)));	
		assertTrue(targets.contains(board.getCell(10, 3)));
		assertTrue(targets.contains(board.getCell(19, 4)));
		assertTrue(targets.contains(board.getCell(29, 21)));
	}

	// Tests out of room center, 1, 3 and 4
	// These are TEAL BLUE on the planning spreadsheet
	@Test
	public void testTargetsAtDoor() {
		// test a roll of 1, at door
		board.calcTargets(board.getCell(2, 9), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(2, 7)));
		assertTrue(targets.contains(board.getCell(1, 9)));	
		assertTrue(targets.contains(board.getCell(3, 9)));	
		
		// test a roll of 3
		board.calcTargets(board.getCell(2, 9), 3);
		targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(2, 7)));
		assertTrue(targets.contains(board.getCell(0, 10)));
		assertTrue(targets.contains(board.getCell(5, 9)));	
		assertFalse(targets.contains(board.getCell(6, 6)));
		assertFalse(targets.contains(board.getCell(3, 5)));	
		
		// test a roll of 4
		board.calcTargets(board.getCell(2, 9), 4);
		targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCell(2, 7)));
		assertTrue(targets.contains(board.getCell(6, 9)));	
		assertFalse( targets.contains(board.getCell(8, 7)));
		assertFalse( targets.contains(board.getCell(1, 4)));	
	}

	@Test
	public void testTargetsInWalkway1() {
		// test a roll of 1
		board.calcTargets(board.getCell(17, 6), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(17, 5)));
		assertTrue(targets.contains(board.getCell(17, 7)));	
		assertTrue(targets.contains(board.getCell(16, 6)));
		assertTrue(targets.contains(board.getCell(18, 6)));	
		
		// test a roll of 3
		board.calcTargets(board.getCell(17, 6), 3);
		targets= board.getTargets();
		assertEquals(15, targets.size());
		assertTrue(targets.contains(board.getCell(14, 6)));
		assertTrue(targets.contains(board.getCell(20, 6)));
		assertTrue(targets.contains(board.getCell(15, 5)));
		assertTrue(targets.contains(board.getCell(15, 7)));
		assertTrue(targets.contains(board.getCell(19, 5)));
		assertTrue(targets.contains(board.getCell(19, 7)));
		assertTrue(targets.contains(board.getCell(18, 4)));
		assertTrue(targets.contains(board.getCell(18, 8)));
		assertTrue(targets.contains(board.getCell(16, 4)));	
		assertTrue(targets.contains(board.getCell(16, 8)));
		assertTrue(targets.contains(board.getCell(17, 3)));
		assertTrue(targets.contains(board.getCell(16, 6)));
		assertTrue(targets.contains(board.getCell(18, 6)));	
		assertTrue(targets.contains(board.getCell(17, 5)));
		assertTrue(targets.contains(board.getCell(17, 7)));
		
		// test a roll of 4
		board.calcTargets(board.getCell(17, 6), 4);
		targets= board.getTargets();
		assertEquals(21, targets.size());
		assertTrue(targets.contains(board.getCell(16, 3)));
		assertTrue(targets.contains(board.getCell(18, 1)));
		assertTrue(targets.contains(board.getCell(18, 3)));	
		assertTrue(targets.contains(board.getCell(15, 4)));
		assertTrue(targets.contains(board.getCell(17, 4)));
		assertTrue(targets.contains(board.getCell(19, 4)));
		assertTrue(targets.contains(board.getCell(14, 5)));
		assertTrue(targets.contains(board.getCell(16, 5)));
		assertTrue(targets.contains(board.getCell(18, 5)));
		assertTrue(targets.contains(board.getCell(20, 5)));
		assertTrue(targets.contains(board.getCell(13, 6)));
		assertTrue(targets.contains(board.getCell(15, 6)));
		assertTrue(targets.contains(board.getCell(19, 6)));
		assertTrue(targets.contains(board.getCell(21, 6)));
		assertTrue(targets.contains(board.getCell(14, 7)));
		assertTrue(targets.contains(board.getCell(16, 7)));
		assertTrue(targets.contains(board.getCell(18, 7)));
		assertTrue(targets.contains(board.getCell(20, 7)));
		assertTrue(targets.contains(board.getCell(15, 8)));
		assertTrue(targets.contains(board.getCell(17, 8)));
		assertTrue(targets.contains(board.getCell(19, 8)));
	}

	@Test
	public void testTargetsInWalkway2() {
		// test a roll of 1
		board.calcTargets(board.getCell(4, 5), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(4, 4)));
		assertTrue(targets.contains(board.getCell(3, 5)));
		assertTrue(targets.contains(board.getCell(5, 5)));
		
		// test a roll of 3
		board.calcTargets(board.getCell(4, 5), 3);
		targets= board.getTargets();
		assertEquals(10, targets.size());
		assertTrue(targets.contains(board.getCell(6, 6)));
		assertTrue(targets.contains(board.getCell(5, 5)));
		assertTrue(targets.contains(board.getCell(2, 4)));
		assertTrue(targets.contains(board.getCell(3, 5)));	
		assertTrue(targets.contains(board.getCell(2, 7)));
		assertTrue(targets.contains(board.getCell(3, 2)));
		
		// test a roll of 4
		board.calcTargets(board.getCell(4, 5), 4);
		targets= board.getTargets();
		assertEquals(13, targets.size());
		assertTrue(targets.contains(board.getCell(1, 4)));
		assertTrue(targets.contains(board.getCell(6, 3)));
		assertTrue(targets.contains(board.getCell(6, 7)));
		assertTrue(targets.contains(board.getCell(7, 6)));
		assertTrue(targets.contains(board.getCell(3, 4)));
		assertTrue(targets.contains(board.getCell(2, 5)));	
		assertTrue(targets.contains(board.getCell(3, 2)));
		assertTrue(targets.contains(board.getCell(2, 7)));
	}

	@Test
	// test to make sure occupied locations do not cause problems
	public void testTargetsOccupied() {
		// test a roll of 4 blocked one unit (1 left, 1 down)
		Set<BoardCell> clearTargets = board.getTargets();
		board.getCell(1, 5).setOccupied(true);
		board.calcTargets(board.getCell(3, 5), 4);
		board.getCell(1, 5).setOccupied(false);
		Set<BoardCell> targets = board.getTargets();
		assertEquals(9, targets.size());
		assertTrue(targets.contains(board.getCell(0, 4)));
		assertTrue(targets.contains(board.getCell(4, 4)));
		assertTrue(targets.contains(board.getCell(5, 5)));	
		assertTrue(targets.contains(board.getCell(6, 4)));	
		assertTrue(targets.contains(board.getCell(6, 6)));
		assertTrue(targets.contains(board.getCell(3, 2)));	
		assertTrue(targets.contains(board.getCell(2, 7)));	
		assertFalse( targets.contains( board.getCell(1, 5))) ;
		//assertFalse( targets.contains( board.getCell(2, 4))) ;
	
		// we want to make sure we can get into a room, even if flagged as occupied
		board.getCell(15, 21).setOccupied(true);
		board.getCell(17, 17).setOccupied(true);
		board.calcTargets(board.getCell(16, 17), 1);
		board.getCell(15, 21).setOccupied(false);
		board.getCell(17, 17).setOccupied(false);
		targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(16, 16)));	
		assertTrue(targets.contains(board.getCell(15, 17)));	
		assertTrue(targets.contains(board.getCell(15, 21)));
		assertFalse(targets.contains(board.getCell(17, 17)));
		
		// check leaving a room with a blocked doorway
		board.getCell(17, 3).setOccupied(true);
		board.calcTargets(board.getCell(18, 1), 2);
		board.getCell(17, 3).setOccupied(false);
		targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(29, 21)));
		assertTrue(targets.contains(board.getCell(11, 2)));	
		assertTrue(targets.contains(board.getCell(10, 1)));
	}

}
