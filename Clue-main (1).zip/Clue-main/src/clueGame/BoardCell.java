/**
 * BoardCell -- a representation of a board cell in the Clue game grid
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/11/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.Set;
import java.util.HashSet;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;

public class BoardCell {
	private static final int CELL_MARGIN = 10;
	
    private int row;
    private int col;
    private Set<BoardCell> adjList;
    private boolean isRoom;
    private boolean isOccupied;
    private boolean doorway;
    private boolean label;
    private boolean roomCenter;
    private boolean isSecretPassage;
    private char secretPassage;
    private DoorDirection doorDirection;
    private Room room;

    // Constructor
    public BoardCell(int row, int col) {
        this.row = row;
        this.col = col;
        adjList = new HashSet<BoardCell>();
    }
    
    public void draw(Graphics g, int cellWidth, int cellHeight) {
        String nameRoom = room.getName();

        // Calculate the position for each cell based on the row and column
        int x = col * cellWidth;  // Column position
        int y = row * cellHeight; // Row position

        // If it's a secret passage, update the color based on the destination room
        if (checkSecretPassage()) {
            char secretRoomChar = getSecretPassage(); // Get the destination room character
            
            // Switch statement to set the color based on the secret passage destination room
            switch (secretRoomChar) {
                case 'M': // MushroomHouse
                    g.setColor(new Color(205, 92, 92)); // Example color for Mushroom House
                    break;
                case 'F': // FairyTree
                    g.setColor(new Color(255, 215, 0)); // Example color for Fairy Tree
                    break;
                case 'A': // Waterfall
                    g.setColor(new Color(25, 25, 112)); // Example color for Waterfall
                    break;
                case 'L': // LilypadPond
                    g.setColor(new Color(173, 216, 230)); // Example color for Lilypad Pond
                    break;
                case 'H': // HobbitHole
                    g.setColor(new Color(0, 100, 0)); // Example color for Hobbit Hole
                    break;
                case 'C': // WitchCave
                    g.setColor(new Color(112, 128, 144)); // Example color for Witch Cave
                    break;
                case 'D': // Dragon'sNest
                    g.setColor(new Color(139, 69, 19)); // Example color for Dragon's Nest
                    break;
                case 'T': // Tower
                    g.setColor(new Color(253, 245, 230)); // Example color for Tower
                    break;
                case 'G': // Gazebo
                    g.setColor(new Color(255, 255, 240)); // Example color for Gazebo
                    break;
                default:
                    g.setColor(Color.WHITE); // Default color if no match
                    break;
            }
        } else {
            // Default color for non-secret passage rooms
            if (nameRoom.equals("Walkway")) {
                g.setColor(new Color(152, 251, 152));  // Light green color for Walkway
            } else if (nameRoom.equals("Unused")) {
                g.setColor(new Color(255, 165, 0)); // Example: Unused color
            } else if (nameRoom.equals("MushroomHouse")) {
                g.setColor(new Color(205, 92, 92)); // Example color for Mushroom House
            } else if (nameRoom.equals("FairyTree")) {
                g.setColor(new Color(255, 215, 0)); // Example color for Fairy Tree
            } else if (nameRoom.equals("Waterfall")) {
                g.setColor(new Color(25, 25, 112)); // Example color for Waterfall
            } else if (nameRoom.equals("LilypadPond")) {
                g.setColor(new Color(173, 216, 230)); // Example color for Lilypad Pond
            } else if (nameRoom.equals("HobbitHole")) {
                g.setColor(new Color(0, 100, 0)); // Example color for Hobbit Hole
            } else if (nameRoom.equals("WitchCave")) {
                g.setColor(new Color(112, 128, 144)); // Example color for Witch Cave
            } else if (nameRoom.equals("Dragon'sNest")) {
                g.setColor(new Color(139, 69, 19)); // Example color for Dragon's Nest
            } else if (nameRoom.equals("Tower")) {
                g.setColor(new Color(253, 245, 230)); // Example color for Tower
            } else if (nameRoom.equals("Gazebo")) {
                g.setColor(new Color(255, 255, 240)); // Example color for Gazebo
            }
        }

        // Fill the cell with the assigned color
        g.fillRect(x, y, cellWidth, cellHeight);

        // Draw the door indicator (only for Walkway) if it's a doorway
        if (nameRoom.equals("Walkway") && isDoorway()) {
            DoorDirection doorDirection = getDoorDirection();  // Get the direction of the door
            
            g.setColor(Color.RED);  // Set color for the door marker
            int doorWidth = 3;  // Thickness of the door marker rectangle

            switch (doorDirection) {
                case UP:
                    // Draw rectangle on top of the cell for 'UP' (North)
                    g.fillRect(x + doorWidth, y, cellWidth - 2 * doorWidth, doorWidth);
                    break;
                case DOWN:
                    // Draw rectangle on the bottom of the cell for 'DOWN' (South)
                    g.fillRect(x + doorWidth, y + cellHeight - doorWidth, cellWidth - 2 * doorWidth, doorWidth);
                    break;
                case LEFT:
                    // Draw rectangle on the left side of the cell for 'LEFT'
                    g.fillRect(x, y + doorWidth, doorWidth, cellHeight - 2 * doorWidth);
                    break;
                case RIGHT:
                    // Draw rectangle on the right side of the cell for 'RIGHT'
                    g.fillRect(x + cellWidth - doorWidth, y + doorWidth, doorWidth, cellHeight - 2 * doorWidth);
                    break;
            }
        }

        // Draw the outline (only for Walkway)
        if (nameRoom.equals("Walkway")) {
            g.setColor(Color.BLACK);  // Set color for outline
            g.drawRect(x, y, cellWidth, cellHeight);  // Draw the outline with no margin
        }
    }

    
    public void draw(Graphics g, int cellWidth, int cellHeight, Color color) {
        String nameRoom = room.getName();

        // Calculate the position for each cell based on the row and column
        int x = col * cellWidth;  // Column position
        int y = row * cellHeight; // Row position
        
        // Fill the cell with the assigned color
        g.setColor(color);
        g.fillRect(x, y, cellWidth, cellHeight);

        // Draw the outline (only for Walkway)
        if (nameRoom.equals("Walkway")) {
            g.setColor(Color.BLACK);  // Set color for outline
            g.drawRect(x, y, cellWidth, cellHeight);  // Draw the outline with no margin
        }
    }

    // 
    public boolean containsClick(int mouseX, int mouseY, int cellWidth, int cellHeight) {
    	// Calculate the position for each cell based on the row and column
        int x = col * cellWidth;  // Column position
        int y = row * cellHeight; // Row position
        
        // build a rectangle and check if the mouse click is within it
    	Rectangle rect = new Rectangle(x, y, cellWidth, cellHeight);
		if (rect.contains(new Point(mouseX, mouseY))) {
			return true;
		}
		return false;
	}

    /*
     * Add a cell to this cell's adjacency list
     */
    public void addAdjacency(BoardCell cell) {
    	adjList.add(cell);
    }

    /*
     * Returns the adjacency list for the cell	
     */
    public Set<BoardCell> getAdjListCell() {
        return adjList;
    }
    
    /*
     * returns door direction
     */
    public DoorDirection getDoorDirection() {
    	return doorDirection;
    }

    // returns the boolean value of its corresponding variable
    public boolean isDoorway() {
        return doorway;
    }
    
    public boolean isLabel() {
        return label;
    }
    
    public boolean isRoomCenter() {
        return roomCenter;
    }

    public boolean checkSecretPassage() {
        return isSecretPassage;
    }
    
    // setters
    public void setRoom(boolean isRoom) {
        this.isRoom = isRoom;
    }
    
    public void setOccupied(boolean isOccupied) {
    	this.isOccupied = isOccupied;
    }
    
    public void setDoorDirection(DoorDirection doorDirection) {
        this.doorDirection = doorDirection;    
    }
    
    public void setSecretPassage(char secretPassage) {
    	this.secretPassage = secretPassage;
        isSecretPassage = true;
    }
    
    public void setDoorway(boolean doorway) {
        this.doorway = doorway;
    }
    
    public void setRoomCenter(boolean roomCenter) {
        this.roomCenter = roomCenter;
    }
    
    public void setCellRoom(Room room) {
        this.room = room;
    }
    
    public void setLabel(boolean label) {
        this.label = label;
    }
    
    // getters
    public boolean getRoom() {
    	return isRoom;
    }
    
    public boolean getOccupied() {
        return isOccupied;
    }
    
    public Room getCellRoom() {
        return room;
    }
    
    public int getRow() {
    	return row;
    }
    
    public int getCol() {
    	return col;
    }
    
    public char getSecretPassage() {
        return secretPassage;
    }

    @Override
    public String toString() {
        return "(" + row + ", " + col + ")";
    }
}