/**
 * ClueGame -- displays the CardPanel, GameControl Panel, and BoardPanel all together
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/20/24
 * Collaborators: None
 * Sources: 
 */
package clueGame;


import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ClueGame extends JFrame {
	private static final long serialVersionUID = 1L;
	Board board;
	private BoardPanel boardPanel;
	private GameControlPanel gameControlPanel;
	private CardPanel cardPanel;
	
	private static ClueGame gameState = new ClueGame();
	
	public static ClueGame getGameState() {
		return gameState;
	}
	
	public void restart() {
		board = Board.getInstance();
		
		setTitle("Clue Game - CSCI 306");
		setSize(800, 900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Set layout
        setLayout(new BorderLayout());

        // Add panels to the JFrame
        add(boardPanel, BorderLayout.CENTER);
        add(gameControlPanel, BorderLayout.SOUTH);
        add(cardPanel, BorderLayout.EAST);
        
        // show itself
        setVisible(true);
        
        // show the splash screen
        JOptionPane.showMessageDialog(this, "You are " + board.getPlayers().get(0).getName() + ".\nCan you find the solution\nbefore the Computer players?");
	}
	
	private ClueGame() {
		board = Board.getInstance();
		
		setTitle("Clue Game - CSCI 306");
		setSize(800, 900);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Initialize panels
        boardPanel = new BoardPanel();
        gameControlPanel = new GameControlPanel();
        cardPanel = new CardPanel();  
        
        // Set layout
        setLayout(new BorderLayout());

        // Add panels to the JFrame
        add(boardPanel, BorderLayout.CENTER);
        add(gameControlPanel, BorderLayout.SOUTH);
        add(cardPanel, BorderLayout.EAST);
        
        // show itself
        setVisible(true);
        
        // show the splash screen
        JOptionPane.showMessageDialog(this, "You are " + board.getPlayers().get(0).getName() + ".\nCan you find the solution\nbefore the Computer players?");
	}
	
	// getters
	public BoardPanel getBoardPanel() {
		return boardPanel;
	}
	
	public GameControlPanel getGameControlPanel() {
		return gameControlPanel;
	}
	
	public CardPanel getCardPanel() {
		return cardPanel;
	}
}
