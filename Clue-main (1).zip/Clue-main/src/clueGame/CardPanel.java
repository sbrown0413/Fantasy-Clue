/**
 * CardPanel -- contains the panel that shows the cards that the player has seen
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/10/24
 * Collaborators: None
 * Sources: 
 */
package clueGame;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


import java.util.ArrayList;

public class CardPanel extends JPanel {
    private JPanel people;
    private JPanel rooms;
    private JPanel weapons;
    private JPanel peopleHand;
    private JPanel peopleSeen;
    private JPanel roomsHand;
    private JPanel roomsSeen;
    private JPanel weaponsHand;
    private JPanel weaponsSeen;

    private static final long serialVersionUID = 1L;

    public CardPanel() {
        // set the grid layout that will hold the other panels
        setLayout(new GridLayout(3, 1));
        setBorder(new TitledBorder(new EtchedBorder(), "Known Cards"));
        
        // build the people panel 
        people = new JPanel();
        people.setLayout(new GridLayout(2, 1));
        people.setBorder(new TitledBorder(new EtchedBorder(), "People"));
        
        // build the people's in hand panel
        peopleHand = new JPanel();
        peopleHand.setLayout(new GridLayout(0, 1));
        
        // Put the label and put the default
        JLabel inPeopleHand = new JLabel("In Hand:");
        JTextField defaultPeopleHand = new JTextField();
        defaultPeopleHand.setText("None");
        defaultPeopleHand.setEditable(false);
        
        peopleHand.add(inPeopleHand);
        peopleHand.add(defaultPeopleHand);
        
        // build the people's seen panel
        peopleSeen = new JPanel();
        peopleSeen.setLayout(new GridLayout(0, 1));
        
        JLabel inPeopleSeen = new JLabel("Seen:");
        JTextField defaultPeopleSeen = new JTextField();
        defaultPeopleSeen.setText("None");
        defaultPeopleSeen.setEditable(false);
        
        peopleSeen.add(inPeopleSeen);
        peopleSeen.add(defaultPeopleSeen);
        
        people.add(peopleHand);
        people.add(peopleSeen);
        
        // build the rooms panel
        rooms = new JPanel();
        rooms.setLayout(new GridLayout(2, 1));
        rooms.setBorder(new TitledBorder(new EtchedBorder(), "Rooms"));
        
        // build the room's in hand panel
        roomsHand = new JPanel();
        roomsHand.setLayout(new GridLayout(0, 1));
        
        // Put the label and put the default
        JLabel inRoomsHand = new JLabel("In Hand:");
        JTextField defaultRoomsHand = new JTextField();
        defaultRoomsHand.setText("None");
        defaultRoomsHand.setEditable(false);
        
        roomsHand.add(inRoomsHand);
        roomsHand.add(defaultRoomsHand);
        
        // build the room's seen panel
        roomsSeen = new JPanel();
        roomsSeen.setLayout(new GridLayout(0, 1));
        
        // Put the label and put the default
        JLabel inRoomsSeen = new JLabel("Seen:");
        JTextField defaultRoomsSeen = new JTextField();
        defaultRoomsSeen.setText("None");
        defaultRoomsSeen.setEditable(false);
        
        roomsSeen.add(inRoomsSeen);
        roomsSeen.add(defaultRoomsSeen);
        
        rooms.add(roomsHand);
        rooms.add(roomsSeen);
        
        // build the weapons panel
        weapons = new JPanel();
        weapons.setLayout(new GridLayout(2, 1));
        weapons.setBorder(new TitledBorder(new EtchedBorder(), "Weapons"));
        
        // build the room's in hand panel
        weaponsHand = new JPanel();
        weaponsHand.setLayout(new GridLayout(0, 1));
        
        // Put the label and put the default
        JLabel inWeaponHand = new JLabel("In Hand:");
        JTextField defaultWeaponHand = new JTextField();
        defaultWeaponHand.setText("None");
        defaultWeaponHand.setEditable(false);
        
        weaponsHand.add(inWeaponHand);
        weaponsHand.add(defaultWeaponHand);
        
        // build the room's seen panel
        weaponsSeen = new JPanel();
        weaponsSeen.setLayout(new GridLayout(0, 1));
        
        // Put the label and put the default
        JLabel inWeaponSeen = new JLabel("In Hand:");
        JTextField defaultWeaponSeen = new JTextField();
        defaultWeaponSeen.setText("None");
        defaultWeaponSeen.setEditable(false);
        
        weaponsSeen.add(inWeaponSeen);
        weaponsSeen.add(defaultWeaponSeen);
        
        weapons.add(weaponsHand);
        weapons.add(weaponsSeen);
        
        add(people);        
        add(rooms);
        add(weapons);
        
      
    }   
    
/**
 * Takes in humanPlayer and sorts the cards based on the cards in hand and the cards seen. It also
 * colors the boxes based on the player who has the card in hand.
 * @param humanPlayer
 */
    public void setCards(HumanPlayer humanPlayer) {
        ArrayList<Card> seen = humanPlayer.getSeenCards();
        ArrayList<Card> hand = humanPlayer.getHand();
        Color playerColor = humanPlayer.getColor();
        
        // Clear existing items in the panels to prevent duplicates
        peopleHand.removeAll();
        peopleSeen.removeAll();
        roomsHand.removeAll();
        roomsSeen.removeAll();
        weaponsHand.removeAll();
        weaponsSeen.removeAll();
        
        // Set default labels
        JLabel inPeopleHand = new JLabel("In Hand:");
        JLabel inPeopleSeen = new JLabel("Seen:");
        JLabel inRoomsHand = new JLabel("In Hand:");
        JLabel inRoomsSeen = new JLabel("Seen:");
        JLabel inWeaponsHand = new JLabel("In Hand:");
        JLabel inWeaponsSeen = new JLabel("Seen:");
        
        peopleHand.add(inPeopleHand);
        peopleSeen.add(inPeopleSeen);
        roomsHand.add(inRoomsHand);
        roomsSeen.add(inRoomsSeen);
        weaponsHand.add(inWeaponsHand);
        weaponsSeen.add(inWeaponsSeen);
        
        // Add cards to hand sections
        for (Card card : hand) {
            JTextField cardField = new JTextField(card.getName());
            cardField.setEditable(false);
            cardField.setBackground(playerColor);
            
            if (card.getCardType() == CardType.CHARACTER) {
                peopleHand.add(cardField);
            } else if (card.getCardType() == CardType.ROOM) {
                roomsHand.add(cardField);
            } else {
                weaponsHand.add(cardField);
            }
        }

        // Add cards to seen sections, skipping duplicates from the hand
        for (Card card : seen) {
            JTextField cardField = new JTextField(card.getName());
            cardField.setEditable(false);

            // Find the player that is holding the card
            Player player = card.getOwner();
            cardField.setBackground(player.getColor());
          
            if(!hand.contains(card)) {
            	if (card.getCardType() == CardType.CHARACTER) {
                    peopleSeen.add(cardField);
                } else if (card.getCardType() == CardType.ROOM) {
                    roomsSeen.add(cardField);
                } else {
                    weaponsSeen.add(cardField);
                }
            }
        }
        
        // Add all categories back to the main panels
        people.add(peopleHand);
        people.add(peopleSeen);
        rooms.add(roomsHand);
        rooms.add(roomsSeen);
        weapons.add(weaponsHand);
        weapons.add(weaponsSeen);

        // Refresh the panel to show the changes
        revalidate();
    }    
    
    public static void main(String[] args) {
    	// Create panel and output it
		CardPanel panel = new CardPanel(); 
		JFrame frame = new JFrame();  
		frame.setContentPane(panel);
		frame.setSize(180, 750);  
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setVisible(true);
		
		// test filling in the data
		Board board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");	
		board.initialize(); // Initialize will load config files 
		
		ArrayList<Player> players = board.getPlayers();
		HumanPlayer human = (HumanPlayer) players.get(0);
		
		Card dagger = new Card("Dagger", CardType.WEAPON);
		Card axe = new Card("Axe", CardType.WEAPON);

		
		Card hobbit = new Card("Hobbit", CardType.CHARACTER);
		Card fairy = new Card("Fairy", CardType.CHARACTER);
		Card dragon = new Card("Dragon", CardType.CHARACTER);
		
		Card fairyTree = new Card("FairyTree", CardType.ROOM);
		Card lilypad = new Card("LilypadPond", CardType.ROOM);
		Card witchCave = new Card("WitchCave", CardType.ROOM);
		
		human.clearHand();
		
        // add these cards to the seen pile
        dagger.setOwner(players.get(0)); 
		human.addSeen(dagger);
        fairy.setOwner(players.get(2)); 
		human.addSeen(fairy);
        axe.setOwner(players.get(1)); 
		human.addSeen(axe);
        dragon.setOwner(players.get(3)); 
		human.addSeen(dragon);
        witchCave.setOwner(players.get(4)); 
		human.addSeen(witchCave);
		
		human.addToHand(dagger);
        lilypad.setOwner(players.get(0)); 
		human.addToHand(lilypad);
        fairyTree.setOwner(players.get(0)); 
		human.addToHand(fairyTree);
        hobbit.setOwner(players.get(0)); 
		human.addToHand(hobbit);
	
		//panel.setCards(computer, board);
		panel.setCards(human);
    }
}
