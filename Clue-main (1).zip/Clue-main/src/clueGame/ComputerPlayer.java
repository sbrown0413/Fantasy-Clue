/**
 * ComputerPlayer -- the players that will be controlled by the algorithm
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;
import java.util.Random;
import java.util.Set;

public class ComputerPlayer extends Player {
	private String type = "Computer";
	private boolean doAccusation;
	
	public ComputerPlayer(String name, String color, int row, int col)  {
        super(name, color, row, col); 
        doAccusation = false;
    }

	public String playerType() {
		return type;
	}
	
	public Solution createSuggestion(BoardCell location) {
		Board board = Board.getInstance();
		
		// the suggestion must have the card of the current room
		Room currentRoom = location.getCellRoom();
		ArrayList<Card> rooms = board.getRoomCards();
		Card room = null;
		
		// get the card of the current room
		for (Card card : rooms) {
			if (card.getName().equals(currentRoom.getName())) {
				room = card;
				break;
			}
		}

		ArrayList<Card> unseen = getUnseenCards();
		Random random = new Random();
		ArrayList<Card> unseenWeapons = new ArrayList<Card>();
		ArrayList<Card> unseenPersons = new ArrayList<Card>();

		for (Card card : unseen) {
			switch (card.getCardType()) {
				case WEAPON:
					unseenWeapons.add(card);
					break;
				case CHARACTER:
					unseenPersons.add(card);
					break;
			}
		}

		// the suggestion will ensure a weapon that has not been seen is randomly chosen
		int randomWeapon = random.nextInt(unseenWeapons.size());
		Card weapon = unseenWeapons.get(randomWeapon);
		// the suggestion will ensure a person that has not been seen is randomly chosen
		int randomPerson = random.nextInt(unseenPersons.size());
		Card person = unseenPersons.get(randomPerson);
		
		setSuggestion(room, weapon, person);
		
		return getSuggestion();
	}
	
	public BoardCell selectTarget(Set<BoardCell> targets) {
		Board board = Board.getInstance();
		
		ArrayList<Card> unseenRooms = new ArrayList<Card>();
		ArrayList<Card> unseen = getUnseenCards();
		for (Card card : unseen) {
			if (card.getCardType() == CardType.ROOM) {
				unseenRooms.add(card);
			}
		}
		
		ArrayList<BoardCell> roomOptions = new ArrayList<BoardCell>();
		ArrayList<Card> rooms = board.getRoomCards();
		
		// if one of the targets is a room that we haven't seen, then choose that one
		for (BoardCell cell : targets) {
			Room currentRoom = cell.getCellRoom();
			// if the target is not a walkway, then it is a room
			if (!currentRoom.getName().equals("Walkway")) {
				String roomName = currentRoom.getName();
				Card room = null;
				
				// get the card of the current room
				for (Card card : rooms) {
					if (card.getName().equals(currentRoom.getName())) {
						room = card;
						break;
					}
				}
				
				if (unseenRooms.contains(room)) {
					roomOptions.add(cell);
				}
			}
		}
		
		Random random = new Random();
		// return a random unseen room if there were any

		if (roomOptions.size() > 0) {
			int randRoom = random.nextInt(roomOptions.size());			
			return roomOptions.get(randRoom);
		}		

		// otherwise, choose a random cell if they are allowed to
		if (targets.size() > 0) {
			int randIndex = random.nextInt(targets.size());
			Object[] targetsArray = targets.toArray();
			return (BoardCell) targetsArray[randIndex];
		}
		
		// if they are not allowed to, then return the same location
		return board.getCell(getRow(), getColumn());
		
	}
	
	// return the last suggestion that was not disproved
	public Solution accuse() {
		return getSuggestion();
	}
	
	// setter
	public void setDoAccusation() {
		doAccusation = true;
	}
	
	// getter
	public boolean doAccusation() {
		return doAccusation;
	}
}
