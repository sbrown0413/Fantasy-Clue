/**
 * Board -- the Clue game board 
 * Authors: Kairi Hoang and Summer Brown
 * Collaborators: None
 * Sources: 
 * https://stackoverflow.com/questions/12130776/slice-string-in-java
 * https://www.geeksforgeeks.org/how-to-find-length-or-size-of-an-array-in-java/
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/trim
 * https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/#
 * https://www.javatpoint.com/java-string-to-char
 * https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/
 * https://www.w3schools.com/java/java_.asp
 */
package clueGame;

import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.util.HashSet;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;


public class Board {
    private BoardCell[][] board;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	private boolean calcDone;
	private int cols;
	private int rows;
	private int turns;
	private String layout;
	private String setup;
	private Map<Character, Room> roomKey;
	private ArrayList<ArrayList<String>> entireBoard;
	private ArrayList<Player> players;
	private ArrayList<Card> weaponCards;
	private ArrayList<Card> playerCards;
	private ArrayList<Card> roomCards;
	private ArrayList<Card> deckCards;
	private ArrayList<Room> rooms;
	private Card[] solution;
	private Card[] accusation;
	private Solution answer;
	private Map<Player, ArrayList<Card>> playerHands;
	private Player playerTurn;
	private ClueGame gameState;

		
	private static Board theInstance = new Board(); // variable used for singleton pattern
     
     // constructor is private to ensure only one can be created
     private Board() { 
 		super();
    }
     
     // this method returns the only Board
     public static Board getInstance() {
    	return theInstance;
    }
     
     /**
      * initialize the board (since we are using singleton pattern)
      */
     public void initialize() {	
    	visited = new HashSet<BoardCell>();
   		targets = new HashSet<BoardCell>();
  		deckCards = new ArrayList<Card>();
  		solution = new Card[3];
  		accusation = new Card[3];
  		answer = new Solution();
  		playerHands = new HashMap<Player, ArrayList<Card>>();
  		calcDone = false;
  		turns = 0;
		// read in the setup file and initialize the hashmap with the corresponding room characters
  		// read in the layout csv and check if the file as written correctly
  		// also store the values from the csv into the entireBoard instance variable
		
		try {
			loadSetupConfig();
			loadLayoutConfig();
		} catch (BadConfigFormatException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		}
		
		// initialize the board
		board = new BoardCell[rows][cols];

		// put a cell in all of the board units	
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				// grab the value stored in this cell location
				String cell = entireBoard.get(row).get(col);
				// the initialize the current cell that is being looked at
				BoardCell boardCell = new BoardCell(row, col);
				board[row][col] = boardCell;

				// grab the character that defines the room
				char roomType = cell.charAt(0);
				char cellType = ' ';

				// create a room for every board cell
				Room currentRoom = roomKey.get(roomType);
				currentRoom.setRoomCell(boardCell);
				boardCell.setCellRoom(currentRoom);				
				
				// Sees if cell is a special cell
				if(cell.length() > 1) {
					cellType = cell.charAt(1);
				}
				
				switch (cellType) {
			    case '<':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.LEFT);
			        break;
			    case '>':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.RIGHT);
			        break;
			    case '^':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.UP);
			        break;
			    case 'v':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.DOWN);
			        break;
			    case '*': // Check if the cell is a room center
			        boardCell.setRoomCenter(true);
			        currentRoom.setCenterCell(boardCell);
			        boardCell.setDoorDirection(DoorDirection.NONE);
			        break;
			    case '#': // Check if the cell is a room label
			        boardCell.setLabel(true);
			        currentRoom.setLabelCell(boardCell);
			        boardCell.setDoorDirection(DoorDirection.NONE);
			        break;
			    default:
			        if (roomKey.containsKey(cellType)) { // Check if the cell is a secret passage
			            boardCell.setSecretPassage(cellType);
			            currentRoom.setSecretPassageCell(boardCell);
				        boardCell.setDoorDirection(DoorDirection.NONE);
			        }
			        break;
				}
			}
		}

		// find the adjacencies of the cells
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				BoardCell boardCell = board[row][col];
				findAdjacencies(boardCell, row, col);
			}			
		}
		
		// shuffle the cards
		int totalCards = roomCards.size() + playerCards.size() + weaponCards.size();
		if (roomCards.size() > 0 && playerCards.size() > 0 && weaponCards.size() > 0) {
			shuffleCards(totalCards);
		}
		
		if (players.size() > 0) {
			// set all of the player's starting locations as occupied
			for (Player player : players) {
				BoardCell occupied = getCell(player.getRow(), player.getColumn());
				occupied.setOccupied(true);
			}
			
			// the beginning player is the human (the first player)
			playerTurn = players.get(0);
			
			// initialize the human's turn for the start of the game
			HumanPlayer human = (HumanPlayer) players.get(0);
			human.setHumanTurn();
			
			// get the GUI
			gameState = ClueGame.getGameState();
		}
	}
     
	/**
	 * Calculates the legal targets for a move from startCell of length pathLength
	 * @param startCell starting cell that we will move from
	 * @param pathlength length of a path
	 */
	public void calcTargets(BoardCell startCell, int pathlength) {
		// once we get the targets value, then we need to reset the array lists
		if (calcDone) {
			visited.clear();
			targets.clear();
			calcDone = false;
		}
		
		Set<BoardCell> adjList = startCell.getAdjListCell();
		// add the current cell to the visited list
		visited.add(startCell);
		
		// go through the adjacent cells
		for(BoardCell adjCell : adjList) {
			// check if the adjacent cell has not been visited and is not occupied unless it's a room (rooms can be occupied and still be gone in)
			if ((!visited.contains(adjCell) && !adjCell.getOccupied()) || (!visited.contains(adjCell) && adjCell.isRoomCenter())) {
				
				visited.add(adjCell);
				if(pathlength == 1) {
					targets.add(adjCell);
				} else if (adjCell.isRoomCenter()) {
					targets.add(adjCell);
				} else {
					calcTargets(adjCell, pathlength - 1);
				}
				visited.remove(adjCell);
			} 
		}	
	}
	
	/**
	 * Take the setup file and unpack it in terms of the program
	 * @throws BadConfigFormatException
	 * @throws FileNotFoundException
	 */
	public void loadSetupConfig() throws BadConfigFormatException, FileNotFoundException {
		// initialize the card, player, and room arrays
  		weaponCards = new ArrayList<Card>();
  		playerCards = new ArrayList<Card>();
  		roomCards = new ArrayList<Card>();
  		rooms = new ArrayList<Room>();
  		players = new ArrayList<Player>();
  		
		// open the file and read from that file
		FileReader reader = new FileReader(setup);
		Scanner in = new Scanner(reader); //Why warning
		
		// This will store the letter as the key and room name as the value
		roomKey = new HashMap<>();
		
		// Reading in lines
		while (in.hasNextLine()) {
			// Gets rid of spaces
			String line = in.nextLine().trim(); 
			
			// Ignores comments
			if (line.startsWith("//")) {
                continue;
            }

			// Splits at commas
			String[] sections = line.split(",");
			String type = sections[0].trim();
			
			
			// Check the formatting of the file
			switch(type) {
				case "Room", "Space":
					if (sections.length != 3) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Room or Space. Needs 3 sections.");
					}
					String name = sections[1].trim();
					char identifier = sections[2].trim().charAt(0);
					
					// create a room with the given information
					Room room = new Room(name);
					// store it into the hashtable
					rooms.add(room);
					
					roomKey.put(identifier, room);
					
					// create the room cards and add it to the roomCards array list
					if (type.equals("Room")) {
						Card roomCard = new Card(name, CardType.ROOM);
						roomCards.add(roomCard);
					}
					break;
				case "Player":
					if (sections.length != 6) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Player. Needs 6 sections.");
					}	
					name = sections[1].trim();
					String color = sections[2].trim();
					String playerType = sections[3].trim();
					int x = Integer.parseInt(sections[4].trim());
					int y = Integer.parseInt(sections[5].trim());
					
					// create the players with the given information
					Player player;
					if (playerType.equals("Human")) {
						player = new HumanPlayer(name, color, x, y);
					} else {
						player = new ComputerPlayer(name, color, x, y);
					}
					
					// add it to the players ArrayList
					players.add(player);
					
					// create the player cards and add it to the playerCards array list
					Card playerCard = new Card(name, CardType.CHARACTER);
					playerCards.add(playerCard);
					break;
				case "Weapon":
					if (sections.length != 2) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Weapon. Needs 2 sections.");
					}
					String weaponType = sections[1].trim();
					
					// create the weapon cards and add it to the weaponCards array list
					Card weaponCard = new Card(weaponType, CardType.WEAPON);
					weaponCards.add(weaponCard);
					break;
				default: // Should ONLY have rooms, spaces, players, and weapons
					throw new BadConfigFormatException("Setup.txt is formatted wrong.");
			}
		}
		// close the file
		in.close();
	} 
	
	/**
	* Loads in the config files and builds the board
	*/
	public void loadLayoutConfig() throws BadConfigFormatException, FileNotFoundException {
		// open the file and read from that file
		entireBoard = new ArrayList<>(); // holds each rows
		FileReader reader = new FileReader(layout);
		Scanner in = new Scanner(reader);	
	
		while (in.hasNextLine()) {
			ArrayList<String> eachRow = new ArrayList<>();
			String line = in.nextLine();
			
			// put the board characters into an array, split based on the commas
			String[] cells = line.split(",");
			
			// add the separated strings into the inner list
			for (String cell : cells) {
				cell = cell.trim();

				// if the cell is empty, then there's a bad format
				if (cell.isEmpty()) {
					in.close();
					throw new BadConfigFormatException("The layout file has missing values.");
				}
				
				// get the first character from the cell
				char room = cell.charAt(0);				
				
				if (roomKey.containsKey(room)) {
					eachRow.add(cell);	
				}
  			 	// otherwise, that cell character is undefined
				else {
					in.close();
					throw new BadConfigFormatException("The layout file contains undefined characters: " + room);
				}
			}
			// then add the inner list to the outer list
			entireBoard.add(eachRow);		
		}		
		in.close();

		// the number of rows equals the number of inner lists made
		rows = entireBoard.size();
		int prevCol = entireBoard.get(0).size();

		// loop through the ArrayLists and check if the column sizes stay consistent, otherwise throw a BadConfigFormatException
		for (int row = 1; row < rows; row++) {
			int currCol = entireBoard.get(row).size();
			if (currCol != prevCol) {
				throw new BadConfigFormatException("The layout file does not have a consist number of columns.");
			}
		}
		
		// store the number of columns in the instance variable as long as we have more than one row
		if (rows != 0) {
			// the number of columns equal to the number of values within each inner list
			cols = entireBoard.get(0).size(); 
		} else {
			cols = 0;
			throw new BadConfigFormatException("The layout file does not contain any information");
		}		
	}
		
	/**
	 * Finds the adjacent cells at a certain board cell and stores them in adjList
	 * @param cell
	 * @param row
	 * @param col
	 */
	public void findAdjacencies(BoardCell cell, int row, int col) {
		int right = col + 1;
		int left = col - 1;
		int up = row - 1;
		int down = row + 1;

		Room currentRoom = cell.getCellRoom();

		// if cell is Doorway (must look at corresponding room coordinates, and find said room in the hash map values the key will tell us what room it is, and if it is a walkway or unused space)
		if (cell.isDoorway()) {
			BoardCell adjCell;
			Room adjRoom = currentRoom; // has to be initialized to a room, but will always get assigned to the correct room after the switch case statements
			
			// Get the door direction
			switch(cell.getDoorDirection()) {
				case RIGHT:
					adjCell = getCell(row, right);
					adjRoom = adjCell.getCellRoom();
					break;
				case LEFT:
					adjCell = getCell(row, left);
					adjRoom = adjCell.getCellRoom();
					break;
				case UP:
					adjCell = getCell(up, col);
					adjRoom = adjCell.getCellRoom();
					break;
				case DOWN:
					adjCell = getCell(down, col);
					adjRoom = adjCell.getCellRoom();
					break;
				default:
			        // Handle unexpected values or add a default behavior
			        adjCell = null;
			        adjRoom = null;
			        break;
			}
			
			BoardCell center = adjRoom.getCenterCell();
			// add the adjacent cell's room center to the door adjacencies
			cell.addAdjacency(center);

			// add the door as an adjacent cell to the room center
			center.addAdjacency(cell);	
			
		} else if (cell.isRoomCenter()) { // check if the cell is a room center
			// room centers are adjacent to secret passage ways and doorways (no other cells)
			
			ArrayList<BoardCell> roomCell = currentRoom.getRoomCell();
			
			// iterate through the room cells and check if they have a secret passage
			for (BoardCell checkCell : roomCell) {
				if (checkCell.checkSecretPassage()) {
					char secretRoomKey = checkCell.getSecretPassage();
					Room secretRoom = roomKey.get(secretRoomKey);
					
					// Add centers of room connected through secret passage ways
					cell.addAdjacency(secretRoom.getCenterCell());
				}
			}		
		} 
		// check if the cell is a walkway or if it was a doorway and add their adjacent walkways
		if (currentRoom.getName().equals("Walkway") || cell.isDoorway()) { 
			addWalkwayAdj(cell, row, left);
			addWalkwayAdj(cell, row, right);
			addWalkwayAdj(cell, up, col);
			addWalkwayAdj(cell, down, col);
		}
	}
	
	/**
	 * Add the adjacent walkway to the current cell
	 * @param cell: current cell
	 * @param adjRow: adjacent row location
	 * @param adjCol: adjacent col location
	 */
	public void addWalkwayAdj(BoardCell cell, int adjRow, int adjCol) {
		// check boundaries
		if (adjRow >= 0 && adjRow < rows && adjCol >= 0 && adjCol < cols) {
			BoardCell adjCell = board[adjRow][adjCol];
			Room adjRoom = adjCell.getCellRoom();
			
			// Check if it is an unoccupied walkway and add the adjacent cell
			if (adjRoom.getName().equals("Walkway") && !adjCell.getOccupied()) {
				cell.addAdjacency(adjCell);
			}
		}
	}
	
	public void shuffleCards(int totalCards) {
		ArrayList<Card> shuffled = new ArrayList<Card>();
		
		// create the solution by putting a random room card, player card, and weapon card
		Random random = new Random();
		
		// generate a random index for the room cards, get the corresponding card and put it in the solution
		int randomCardIndex = random.nextInt(roomCards.size());
		Card randomCard = roomCards.get(randomCardIndex);
		solution[0] = randomCard;
		answer.setRoomCard(randomCard);
		// add this to the deck for the beginning cards that won't be looked at
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;

		randomCardIndex = random.nextInt(playerCards.size());
		randomCard = playerCards.get(randomCardIndex);
		solution[1] = randomCard;
		answer.setPlayerCard(randomCard);
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;
		
		randomCardIndex = random.nextInt(weaponCards.size());
		randomCard = weaponCards.get(randomCardIndex);
		solution[2] = randomCard;
		answer.setWeaponCard(randomCard);
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;
		
		// put all of the cards in the deck of cards
		for (Card card : roomCards) {
			deckCards.add(card);
		}
		
		for (Card card : playerCards) {
			deckCards.add(card);
		}
		
		for (Card card : weaponCards) {
			deckCards.add(card);
		}

		// shuffle the deck
		while (deckCards.size() > 0) {
			int randomIndex = random.nextInt(deckCards.size());
			Card shuffledCard = deckCards.get(randomIndex);
			if (!shuffled.contains(shuffledCard)) {
				shuffled.add(shuffledCard);
				deckCards.remove(shuffledCard);
				totalCards--;
			} else {
				deckCards.remove(shuffledCard);
			}
		}

		// now set the deck to the shuffled deck
		deckCards = shuffled;
		
		// deal the remaining cards to the players
		int skip = 3;
		int dealPlayer = 0;
		for (Card card : deckCards) {
			// skip the first three cards 
			if (skip > 0) {
				skip--;
				continue;
			}
			
			// if the rotation is past the last player in the array list, start over from the first index		
			// add the card to the next player's hand
			Player player = players.get(dealPlayer % players.size());
			player.addToHand(card);
			card.setOwner(player);
			dealPlayer++;
		}
		
		// put each player and their hands into the hashmap
		for (Player player : players) {
			playerHands.put(player, player.getHand());
		}
	}
	
	public void makeAccusation(Card card1, Card card2, Card card3) {
		switch(card1.getCardType()) {
			case ROOM:
				accusation[0] = card1;
				break;
			case CHARACTER:
				accusation[1] = card1;
				break;
			case WEAPON:
				accusation[2] = card1;
				break;
		}
		switch(card2.getCardType()) {
			case ROOM:
				accusation[0] = card2;
				break;
			case CHARACTER:
				accusation[1] = card2;
				break;
			case WEAPON:
				accusation[2] = card2;
				break;
		}
		switch(card3.getCardType()) {
			case ROOM:
				accusation[0] = card3;
				break;
			case CHARACTER:
				accusation[1] = card3;
				break;
			case WEAPON:
				accusation[2] = card3;
				break;
		}
	}
	
	// overloaded accusation function for different types of accusation inputs
	public void makeAccusation(Solution cards) {
		accusation[0] = cards.getRoom();
		accusation[1] = cards.getPerson();
		accusation[2] = cards.getWeapon();
	}
	
	public boolean checkAccusation() {
		if (accusation[0].equals(solution[0]) && accusation[1].equals(solution[1]) && accusation[2].equals(solution[2])) {
			return true;
		}
		return false;
	}

	public Card handleSuggestion(Solution suggestion, Player playerSuggest) {
		Card cardRoom = suggestion.getRoom();
		Room suggestedRoom = null;
		
		// find the room
		for (Room room : rooms) {
			if (room.getName().equals(cardRoom.getName())) {
				suggestedRoom = room;
				break;
			}
		}
		
		String character = suggestion.getPerson().getName();
	
		// go through every player unless it is the character that is making the suggestion
		if (!playerSuggest.getName().equals(character)) {
			for (Player player : players) {
				// if the player matches the one that is being suggested, then put them in the new location and show it on the board
				if (player.getName().equals(suggestion.getPerson().getName())) {
					BoardCell start = getCell(player.getRow(), player.getColumn());
					start.setOccupied(false);
					
					BoardCell cell = suggestedRoom.getCenterCell();
					int cellRow = cell.getRow();
					int cellCol = cell.getCol();
					
					player.setLocation(cellRow, cellCol);
					cell.setOccupied(true);
					
					gameState.getBoardPanel().revalidate();
					gameState.getBoardPanel().repaint();
					
					// check if it is the human player, and if so, mark them so that they are able to stay in the current room and make a suggestion
					if (player.playerType().equals("Human")) {
						HumanPlayer human = (HumanPlayer) player;
						human.setSuggestedMove(true);
						human.setInclude(cell);
					}
					
					break;
				}
			}
		}
		
		// go through every player to find a disproved card
		for (Player player : players) {
			// unless it is the player that made the suggestion
			if (player == playerSuggest) {
				continue;
			} else {
				// grab the disproved card 
				Card card = player.disproveSuggestion(suggestion);
				if (card != null) {
					playerSuggest.addSeen(card);
					return card;
				}
			}
		}
		
		return null;
	}
	
	// use this when it's the next player's turn
	public void setPlayerTurn() {
		// keeps track of the turns
		turns++;
		playerTurn = players.get(turns % players.size());
		
		// if we get to the human player, set the human's turn as unfinished
		if (playerTurn.playerType().equals("Human")) {			
			HumanPlayer human = (HumanPlayer) playerTurn;
			human.setFinishedTurn(false);
			human.setHumanTurn();
			
			// if they were moved, then add the room to the target list
			if (human.getSuggestedMove()) {
				human.addTarget();
				human.setSuggestedMove(false);
				human.setInclude(null);
			}
			
			// set the panel to nothing so that it does not show a guess
			gameState.getGameControlPanel().setGuess("", human);
			gameState.getGameControlPanel().setGuessResult("", human);
			
			gameState.getGameControlPanel().setTurn(human, human.getRoll());
		}
	}
	
	// the logic behind the next button in game control panel
	public void nextButton() {
		Player player = getPlayerTurn();
		
		// if the current turn is on the human, make sure the human is done with their turn
		if (player.playerType().equals("Human")) {
			HumanPlayer human = (HumanPlayer) player;
			
			// if the human is done, then go to the next player
			if (human.getFinishedTurn()) {
				// go to the next player
				setPlayerTurn();
				ComputerPlayer nextPlayer = (ComputerPlayer) getPlayerTurn();
				
				// do the computer player's actions
				computerTurn(nextPlayer);
			
			} else { // otherwise, display an error message if the human is not done
				JOptionPane.showMessageDialog(gameState.getBoardPanel(), "You are not finished with your turn.");
			}
		} else { // otherwise, do the next player's actions
			// go to the next player
			setPlayerTurn();
			Player nextPlayer = getPlayerTurn();
			
			// if it is a computer, do the computer player's actions
			if (nextPlayer.playerType().equals("Computer")) {
				ComputerPlayer computer = (ComputerPlayer) nextPlayer;
				computerTurn(computer);
			}
		}
		// update the visuals
		gameState.getBoardPanel().repaint();
	}
	
	// what the computer will do when next is hit
	public void computerTurn(ComputerPlayer player) {
		GameControlPanel gameControlPanel = gameState.getGameControlPanel(); 
		BoardPanel boardPanel = gameState.getBoardPanel(); 
		// roll the dice for the next player
		player.roll();
			
		// use calc targets
		BoardCell start = getCell(player.getRow(), player.getColumn());
		start.setOccupied(false);
		calcTargets(start, player.getRoll());
		
		// check if the player can play 
		if (!player.getFinishedTurn()) {
			// update the game control panel
			gameControlPanel.setTurn(player, player.getRoll());	
			
			// accusation?
			if (player.doAccusation()) {
				Solution accusation = player.accuse();
				makeAccusation(accusation);
				
				// if the accusation is correct, then end the game -- might need to change this
				if (checkAccusation()) {
					JOptionPane.showMessageDialog(boardPanel, player.getName() + " won the game!");
					// Replace the content of the frame with the GameOverPanel
				    
				    gameState.getContentPane().removeAll(); // Clear current content
				    gameState.getContentPane().add(new GameOverPanel()); // Add GameOverPanel
				    gameState.revalidate(); // Refresh the frame
				    gameState.repaint(); // Ensure the GameOverPanel displays properly
				} else { // otherwise, the player cannot make anymore turns
					JOptionPane.showMessageDialog(boardPanel, player.getName() + " lost the game :/");
					player.setFinishedTurn(true);
				}	
			} else { // move				
				HashSet<BoardCell> targets = (HashSet<BoardCell>) getTargets();
				BoardCell move = player.selectTarget(targets);
				move.setOccupied(true);
				player.setLocation(move.getRow(), move.getCol());
				
				// set the panel to nothing so that it does not show a guess
				gameControlPanel.setGuess("", player);
				gameControlPanel.setGuessResult("", player);
				
				// make a suggestion if they are in a room
				BoardCell location = getCell(player.getRow(), player.getColumn());
				if (!location.getCellRoom().getName().equals("Walkway")) {
					Solution suggestion = player.createSuggestion(location);
					gameControlPanel.setGuess(suggestion.getPerson().getName() + ", " + suggestion.getRoom().getName() + ", " + suggestion.getWeapon().getName(), player);
					
					// check the suggestion, and display if a card was used to disprove
					Card result = handleSuggestion(suggestion, player);
					if (result != null) {
						// make the card as seen by the computer player
						player.addSeen(result);
						gameControlPanel.setGuessResult("Suggestion disproved!", result.getOwner());
					} else { // the suggestion was not disproven and will be guessed next round
						player.setDoAccusation();
						gameControlPanel.setGuessResult("No new clue.");
					}
				}
			}
		} else { // otherwise, just update the game control panel
			gameControlPanel.setTurn(player, 0);
		}
	}

	// handling suggestions coming from the human
	public void humanSuggestions() {	
		HumanPlayer human = (HumanPlayer) playerTurn;
		
		// update the frame components
		GameControlPanel gameControlPanel = gameState.getGameControlPanel();
		CardPanel cardPanel = gameState.getCardPanel();
		BoardPanel boardPanel = gameState.getBoardPanel();
		
		// handle suggestions
		Card character = null;
		Card weapon = null;
		Card room = null;
		
		for (Card card : playerCards) {
			if (boardPanel.getCharacter().equals(card.getName())) {
				character = card;
				break;
			}
		}
		
		for (Card card : weaponCards) {
			if (boardPanel.getWeapon().equals(card.getName())) {
				weapon = card;
				break;
			}
		}
		
		for (Card card : roomCards) {
			if (boardPanel.getRoom().equals(card.getName())) {
				room = card;
				break;
			}
		}
		
		human.setSuggestion(character, weapon, room);
		Solution suggestion = human.getSuggestion();
		
		// show to suggestion to the user
		gameControlPanel.setGuess(suggestion.getPerson().getName() + ", " + suggestion.getRoom().getName() + ", " + suggestion.getWeapon().getName(), human);
			
		// check the suggestion, and display if a card was used to disprove
		Card result = handleSuggestion(suggestion, human);
		if (result != null) {
			gameControlPanel.setGuessResult(result.getName(), result.getOwner());
			// update the card panel
			cardPanel.setCards(human);
		} else {
			gameControlPanel.setGuessResult("No new clue.");
		}
		
		// mark the human as finished
		human.setFinishedTurn(true);
	}
	
	public void humanAccusations() {
		// handle accusations
		//accusation = getAccusation();
		BoardPanel boardPanel = gameState.getBoardPanel(); 
		
		if(checkAccusation()) {
			JOptionPane.showMessageDialog(boardPanel, "YOU WON THE GAME!");
		} else {
			JOptionPane.showMessageDialog(boardPanel, "YOU LOST THE GAME :/ \n \n The solution was: (" + answer.getRoom().getName() + ", " + answer.getPerson().getName() + ", " + answer.getWeapon().getName() + ")");
		}
		
		// Replace the content of the frame with the GameOverPanel
		gameState.getContentPane().removeAll(); // Clear current content
		gameState.getContentPane().add(new GameOverPanel()); // Add GameOverPanel
	    gameState.revalidate(); // Refresh the frame
	    gameState.repaint(); // Ensure the GameOverPanel displays properly
	}
	
	public void accusationButton() {
		Player player = getPlayerTurn();
		
		// only pop up the accusation button when it is human
		if (player.playerType().equals("Human")) {
	        gameState.getBoardPanel().handleHumanAccusation();
		} else {
			// otherwise, put error message
			JOptionPane.showMessageDialog(gameState.getBoardPanel(), "You can't make an accusation when it's not your turn.");
		}
	}

	public void restartGame() {
        // Close the existing game window (if it exists)
        GameOverPanel currentFrame = GameOverPanel.getGameOverPanel();
        if (currentFrame != null) {
            currentFrame.setVisible(false);
        }

        // Set config files and initialize the board
        this.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
        this.initialize();

        // Re-initialize the game control and other panels
        GameControlPanel gameControlPanel = gameState.getGameControlPanel();
        BoardPanel boardPanel = gameState.getBoardPanel();
        CardPanel cardPanel = gameState.getCardPanel();

        // Re-set the player's turn and card information
        HumanPlayer human = (HumanPlayer) getPlayerTurn();
        turns = 0;
        
        gameControlPanel.setTurn(human, human.getRoll());
        cardPanel.setCards(human);
        
        gameState.restart();
    }
	
	// setters
	public void setConfigFiles(String csv, String txt) {
		layout = "data/" + csv;
		setup = "data/" + txt;
	}
	
	public Card[] setSolution(Card weapon, Card character, Card room) {
		solution[0] = room;
		solution[1] = character;
		solution[2] = weapon;
		return solution;
	}
	
	public void setPlayerTurn(Player player) {
		playerTurn = player;
	}
	
	public void clearOccupiedCells() {
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				getCell(row, col).setOccupied(false);
			}
		}
	}
	
	// getters
	public Set<BoardCell> getTargets() {	
		calcDone = true;
		return targets;
	}
	
	public Set<BoardCell> getAdjList(int row, int col) {
		BoardCell cell = getCell(row, col);
		Set<BoardCell> adjList = cell.getAdjListCell();
		return adjList;
	}
	
	public BoardCell[][] getBoard() {
		return board;
	}
	
	public BoardCell getCell(int row, int col) {
		return board[row][col];
	}
	
	public Room getRoom(char roomRep) {
		return roomKey.get(roomRep);
	}

	public Room getRoom(BoardCell cell) {
		return cell.getCellRoom();
	}

	public int getNumRows() {
		return rows;
	}

	public int getNumColumns() {
		return cols;
	}

	public ArrayList<Player> getPlayers() {
        return players;
    }
	
	public ArrayList<Card> getRoomCards() {
		return roomCards;
	}
	
	public ArrayList<Card> getWeaponCards() {
		return weaponCards;
	}
	
	public Card getCardFromName(String name) {
		ArrayList<Card> roomCards = getRoomCards();
		ArrayList<Card> playerCards = getPlayerCards();
		ArrayList<Card> weaponCards = getWeaponCards();
		
		for (Card card : roomCards) {
			if (card.getName().equals(name)) {
				return card;
			}
		}
		for (Card card : playerCards) {
			if (card.getName().equals(name)) {
				return card;
			}
		}
		for (Card card : weaponCards) {
			if (card.getName().equals(name)) {
				return card;
			}
		}
		return null;
	}
	
	public ArrayList<Card> getPlayerCards() {
		return playerCards;
	}
	
	public ArrayList<Card> getDeckCards() {
		return deckCards;
	}
	
	public Card[] getSolution() {
		return solution;
	}
	
	public Map<Player, ArrayList<Card>> getPlayerHands() {
		return playerHands;
	}
	
	public Card[] getAccusation() {
		return accusation;
	}
	
	public ArrayList<Room> getRooms() {
		return rooms;
	}
	
	public Player getPlayerTurn() {
		return playerTurn;
	}
	
	public Set<BoardCell> getRoomCells(Room room) {
		Set<BoardCell> roomCells = new HashSet<>();
		
		for(BoardCell[] row : board) {
			for(BoardCell cell : row) {
				Room type = cell.getCellRoom();
				if(type.getName().equals(room.getName())) {
					roomCells.add(cell);
				}
			}
		}
		
		return roomCells;
	}

	public static void main(String[] args) {
		// Get the instance of ClueGame and the Board
        Board board = Board.getInstance();
        board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");	
		board.initialize(); // Initialize will load config files 
        
		ClueGame frame = ClueGame.getGameState();	
        
		GameControlPanel gameControlPanel = frame.getGameControlPanel();
		BoardPanel boardPanel = frame.getBoardPanel();
		CardPanel cardPanel = frame.getCardPanel();
		
        // Initialize the panels for the start of the game
        HumanPlayer human = (HumanPlayer) board.getPlayerTurn();
        
        gameControlPanel.setTurn(human, human.getRoll());
        cardPanel.setCards(human); 
	}
	


}