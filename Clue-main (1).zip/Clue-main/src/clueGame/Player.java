/**
 * Player -- contains the players for the Clue Game
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;
import java.util.Random;
import java.awt.Color;
import java.awt.Graphics;

public abstract class Player {
	private String name;
	private String colorName;
	private Color color;
	private int row;
	private int column;
	private ArrayList<Card> hand;
    private ArrayList<Card> seen;
	private Solution suggestion;
	private boolean finishedTurn;
	private int roll;	
    
    public Player(String name, String color, int row, int col) {
    	this.name = name;
        this.row = row;
        this.column = col;
        hand = new ArrayList<Card>();
        seen = new ArrayList<Card>();
        colorName = color;
        convertColor(color);
        finishedTurn = false;
    }
    
    public Card disproveSuggestion(Solution otherSuggestion) {
        ArrayList<Card> matches = new ArrayList<Card>();
        // check if the player's hand contains any of the suggestion cards, otherwise return null
        Card room = otherSuggestion.getRoom();
        Card person = otherSuggestion.getPerson();
        Card weapon = otherSuggestion.getWeapon();

    	if (hand.contains(room)) {
            matches.add(room);
        } 
        if (hand.contains(person)) {
            matches.add(person); 
        }
        if (hand.contains(weapon)) {
            matches.add(weapon);
        }
        if (matches.size() > 0) {
            Random random = new Random();
            int index = random.nextInt(matches.size());
            return matches.get(index);
        }
        // otherwise return null if there are no matches
        return null;
    }
    
    // draw the player normally
    public void draw(Graphics g, int cellWidth, int cellHeight) {
        g.setColor(getColor());

        int x = getColumn() * cellWidth;
        int y = getRow() * cellHeight;

        int diameter = Math.min(cellWidth, cellHeight) - 4;

        g.fillOval(x + (cellWidth - diameter) / 2, y + (cellHeight - diameter) / 2, diameter, diameter);

        g.setColor(Color.BLACK);
        g.drawOval(x + (cellWidth - diameter) / 2, y + (cellHeight - diameter) / 2, diameter, diameter);
    }
    
    // draw the player adjusted
    public void drawAdjust(Graphics g, int cellWidth, int cellHeight, int players) {
        g.setColor(getColor());

        int x = getColumn() * cellWidth - 5 * players;
        int y = getRow() * cellHeight;

        int diameter = Math.min(cellWidth, cellHeight) - 4;

        g.fillOval(x + (cellWidth - diameter) / 2, y + (cellHeight - diameter) / 2, diameter, diameter);

        g.setColor(Color.BLACK);
        g.drawOval(x + (cellWidth - diameter) / 2, y + (cellHeight - diameter) / 2, diameter, diameter);
    }

    // clear the player's hand (for testing purposes)
    public void clearHand() {
        hand.clear();
        seen.clear();
    }
    
    // convert colors to their respective colors in Java
    public void convertColor(String colorName) {
    	switch(colorName) {
    		case "Green":
    			color = new Color(107, 142, 35);
    			break;
    			
    		case "Pink":
    			color = new Color(255, 92, 203);
    			break;
    		
    		case "Gray":
    			color = new Color(169, 169, 169);
    			break;
    			
    		case "Teal":
    			color = new Color(32, 178, 170);
    			break;
    			
    		case "Red":
    			color = new Color(139, 0, 0);
    			break;
    		
    		case "Purple":
    			color = new Color(147, 112, 219);
    			break;
    		
    		default:
    			color = new Color(240, 248, 255);
    			break;
    	}
    }
    
    // setters
    public void addToHand(Card card) {
    	hand.add(card);
        seen.add(card);
    }
    
    public void setSuggestion(Card card1, Card card2, Card card3) {
    	suggestion = new Solution(card1, card2, card3);
    }

    public void addSeen(Card card) {
        if (!seen.contains(card)) {
            seen.add(card);
        }
    }

    public void setLocation(int row, int col) {
        this.row = row;
        this.column = col;
    }

    public void setFinishedTurn(boolean finished) {
    	finishedTurn = finished;
    }
    
    public void setRow(int row) {
    	this.row = row;    
    }
    
    public void setColumn(int column) {
    	this.column = column;    
    }
    
    public void roll() {
    	Random random = new Random();
    	roll = random.nextInt(6) + 1;
    }
    
    // getters
    public String getName() {
        return name;
    }

    public Color getColor() {
        return color;
    }
    
    public String getColorName() {
    	return colorName;
    }

    public int getRow() {
    	return row;
    }
    
    public int getColumn() {
    	return column;
    }
    
    public ArrayList<Card> getHand() {
    	return hand;
    }

    public Solution getSuggestion() {
        return suggestion;
    }
    
    public ArrayList<Card> getSeenCards() {
    	return seen;
    }
    
    public boolean getFinishedTurn() {
    	return finishedTurn;
    }
    
    public int getRoll() {
    	return roll;
    }
   
    public ArrayList<Card> getUnseenCards() {
    	ArrayList<Card> unseen = new ArrayList<Card>();
    	
    	Board board = Board.getInstance();
		ArrayList<Card> deck = board.getDeckCards();
		for(Card cardDeck: deck) {
			boolean inSeen = false;
			for(Card cardSeen: seen) {
				if(cardSeen.equals(cardDeck)) {
					inSeen = true;
				}
			}
			if(!inSeen) {
				unseen.add(cardDeck);
			}
		}
		return unseen;
	}
    
    // an abstract method to determine which child class the player was implemented as
    public abstract String playerType();
}
