/* GameOverPanel -- contains the panel that shows the game over screen and play again button
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/24/24
 * Collaborators: None
 * Sources: None
 */

package clueGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameOverPanel extends JPanel {
    private static GameOverPanel gameOver;

    public GameOverPanel() {
    	gameOver = this;
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS)); // Use vertical alignment
        setBackground(Color.BLACK); // Set background color to black

        // Display "Game Over" message
        JLabel gameOverLabel = new JLabel("Game Over", JLabel.CENTER);
        gameOverLabel.setFont(new Font("Arial", Font.BOLD, 200));
        gameOverLabel.setForeground(Color.RED);
        gameOverLabel.setAlignmentX(CENTER_ALIGNMENT); // Center horizontally
        add(Box.createVerticalStrut(100)); // Add vertical spacing
        add(gameOverLabel);

        // Add "Play Again" button
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setFont(new Font("Arial", Font.PLAIN, 24));
        playAgainButton.setPreferredSize(new Dimension(200, 50)); // Set button size
        playAgainButton.setAlignmentX(CENTER_ALIGNMENT); // Center horizontally
        playAgainButton.addActionListener(new PlayAgainListener());
        add(Box.createVerticalStrut(20)); // Add spacing between text and button
        add(playAgainButton);
    }
    
    public static GameOverPanel getGameOverPanel() {
        return gameOver;
    }

    private class PlayAgainListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Properly restart the game
        	Board board = Board.getInstance();
        	board.restartGame();
        }
    }
}

