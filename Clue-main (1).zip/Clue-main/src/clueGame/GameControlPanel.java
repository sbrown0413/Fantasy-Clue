/**
 * GameControlPanel -- contains the panel that shows the game events (roll of the die, turn, etc)
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/10/24
 * Collaborators: None
 * Sources: https://www.geeksforgeeks.org/java-swing-jpanel-with-examples/#
 * https://www.geeksforgeeks.org/java-awt-color-class/#
 */
package clueGame;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


public class GameControlPanel extends JPanel {
	private JTextField turnDisplay; 
	private JTextField diceRollDisplay;
    private JTextField guessDisplay;
    private JTextField guessResultDisplay;
    JComboBox<String> personCombo;
    JComboBox<String> weaponCombo;
    JComboBox<String> roomCombo;

	private static final long serialVersionUID = 1L; 
    
    /**
	 * Constructor for the panel, it does 90% of the work
	 */
    public GameControlPanel()  {
    	// the panel that holds everything
    	setLayout(new GridLayout(2, 0));
    	
    	// build upper JPanel of the GameControlPanel
    	JPanel upperPanel = new JPanel();
    	upperPanel.setLayout(new GridLayout(1, 4));
    	
    	
    	// build the left JPanel of the upperPanel
    	JPanel upperLeftPanel = new JPanel();
    	upperLeftPanel.setLayout(new GridLayout(3, 1));
    	
    	// display the turn
    	JLabel turn = new JLabel("Whose turn?");
    	// initialize the JTextField, which will be updated later
    	turnDisplay = new JTextField();  
    	
    	// fill in the space so that the box looks closer together
    	JPanel upperLeftFiller = new JPanel();
    	
    	// add this onto the upperPanel
    	upperLeftPanel.add(turn);
    	upperLeftPanel.add(turnDisplay);
    	upperLeftPanel.add(upperLeftFiller);

    	// build the middle left of the upperPanel
    	JPanel upperMiddlePanel = new JPanel();
        upperMiddlePanel.setLayout(new GridLayout(2, 2));

        // fill in the space so that the box looks closer together
        JPanel upperMiddleFiller = new JPanel();
        
        // display the dice roll
        JLabel roll = new JLabel("Roll:");
        diceRollDisplay = new JTextField();
        diceRollDisplay.setEditable(false);
        
        // add this onto upperMiddlePanel
        upperMiddlePanel.add(roll);
        upperMiddlePanel.add(diceRollDisplay);
        upperMiddlePanel.add(upperMiddleFiller);

        // build lower JPanel of the GameControlPanel
        JPanel lowerPanel = new JPanel();
        lowerPanel.setLayout(new GridLayout(0, 2));

        // build left JPanel of the lower panel
        JPanel lowerLeftPanel = new JPanel();
    	lowerLeftPanel.setLayout(new GridLayout(1, 0));

    	 // set an etched border with a title for guess
    	lowerLeftPanel.setBorder(new TitledBorder(new EtchedBorder(), "Guess"));
    	// initialize the JTextField, which will be updated later
    	guessDisplay = new JTextField();
    	guessDisplay.setEditable(false);

        lowerLeftPanel.add(guessDisplay);

        // build left JPanel of the lower panel
        JPanel lowerRightPanel = new JPanel();
    	lowerRightPanel.setLayout(new GridLayout(1, 0));

        // set an etched border with a title for guess result
    	lowerRightPanel.setBorder(new TitledBorder(new EtchedBorder(), "Guess Result"));
    	// initialize the JTextField, which will be updated later
    	guessResultDisplay = new JTextField();
    	guessResultDisplay.setEditable(false);

        lowerRightPanel.add(guessResultDisplay);
    	
        JButton accusationButton = new JButton("Make Accusation");
        JButton nextButton = new JButton("NEXT!");
        
        // implement the action listener for the next button
        nextButton.addActionListener(new NextListener());
        accusationButton.addActionListener(new AccusationListener());

		
		upperPanel.add(upperLeftPanel);
		upperPanel.add(upperMiddlePanel);
		upperPanel.add(accusationButton);
		upperPanel.add(nextButton);

        lowerPanel.add(lowerLeftPanel);
        lowerPanel.add(lowerRightPanel);
        
        add(upperPanel);
        add(lowerPanel);
	}

    public void setGuess(String guess) {
        guessDisplay.setText(guess);
    }
    
    public void setGuess(String guess, Player player) {
    	Color color = player.getColor();
    	
        guessDisplay.setText(guess);
        guessDisplay.setBackground(color);
    }

    public void setTurn(Player player, int roll) {
        Color color = player.getColor();
        
    	turnDisplay.setText(player.getName());     
    	turnDisplay.setEditable(false);
        turnDisplay.setBackground(color);
        diceRollDisplay.setText(String.valueOf(roll));
    }

    public void setGuessResult(String result) {
        guessResultDisplay.setText(result);
    }
    
    public void setGuessResult(String result, Player player) {
    	Color color = player.getColor();
    	
        guessResultDisplay.setText(result);
        guessResultDisplay.setBackground(color);
    }
    
    // what the Next button will do when pressed
	private class NextListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			Board board = Board.getInstance();		
			board.nextButton();
		}
	}
	
	private class AccusationListener implements ActionListener {
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        Board board = Board.getInstance();
	    	board.accusationButton();
	    }
	       
	}

	
    /**
	 * Main to test the panel
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		//Create panel and output it
		GameControlPanel panel = new GameControlPanel();  
		JFrame frame = new JFrame();  
		frame.setContentPane(panel); 
		frame.setSize(750, 180);  
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		// test filling in the data
		panel.setTurn(new ComputerPlayer( "Witch", "Gray", 32, 16), 5);
		panel.setGuess( "I have no guess!");
		panel.setGuessResult( "So you have nothing?");
	}
}
