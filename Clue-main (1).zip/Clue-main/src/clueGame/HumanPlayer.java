/**
 * HumanPlayer -- the players that will be controlled by the user
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.Set;

public class HumanPlayer extends Player {
	private String type = "Human";
	private Set<BoardCell> currentTargets;
	private BoardCell include;
	private boolean moved;
	private boolean suggestedMove;
	
	public HumanPlayer(String name, String color, int row, int col)  {
        super(name, color, row, col);
        moved = false;
    }
	
	public void addTarget() {
		currentTargets.add(include);
	}
	
	// setters
	public void setHumanTurn() {
        Board board = Board.getInstance();
        
		// initialize the human player's roll and targets list along with anything else to reset the player
        BoardCell location = board.getCell(getRow(), getColumn());
        roll();
		board.calcTargets(location, getRoll());
		currentTargets = board.getTargets();
		moved = false;
	}
	
	public void setMoved(boolean moved) {
		this.moved = moved;
	}
	
	public void setSuggestedMove(boolean suggested) {
		suggestedMove = suggested;
	}
	
	public void setInclude(BoardCell cell) {
		include = cell;
	}
	
	// getters
	public String playerType() {
		return type;
	}
	
	public Set<BoardCell> getCurrentTargets() {
		return currentTargets;
	}
	
	public boolean getMoved() {
		return moved;
	}
	
	public boolean getSuggestedMove() {
		return suggestedMove;
	}
}
