/**
 * BoardPanel -- contains the panel that shows the board, including rooms, players
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/20/24
 * Collaborators: None
 * Sources: 
 */
package clueGame;

import java.util.Set;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;

import javax.swing.Timer;            // For Timer
import java.awt.event.ActionListener; // For ActionListener
import java.awt.event.ActionEvent;    // For ActionEvent


public class BoardPanel extends JPanel implements MouseListener {
	private static final long serialVersionUID = 1L;
	private Board board;
	private int numCols;
	private int numRows;
	private int cellWidth;
    private int cellHeight;
    JComboBox<String> personCombo;
    JComboBox<String> weaponCombo;
    JComboBox<String> roomCombo;
    private String character;
    private String weapon;
    private String room;
	
    public BoardPanel() {
        board = Board.getInstance();
		numCols = board.getNumColumns();
		numRows = board.getNumRows();
        setLayout(new GridLayout(board.getNumRows(), board.getNumColumns()));
        addMouseListener(this); // board panel will listen to mouse clicks
    }
    
    @Override
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        cellWidth = getCellWidth();
		cellHeight = getCellHeight();
		
        // Draw each cell
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                BoardCell cell = board.getCell(row, col);
                cell.draw(graphics, cellWidth, cellHeight);
            }
        }
        
        ArrayList<BoardCell> playerPositions = new ArrayList<BoardCell>();
        ArrayList<Integer> playerCount = new ArrayList<Integer>();
        
        // Draw each player
        for (Player player : board.getPlayers()) {
        	// if there are more than one player in a room, then adjust the drawing
        	BoardCell playerLoc = board.getCell(player.getRow(), player.getColumn());
        	if (playerPositions.contains(playerLoc)) {
        		// find the index of the shared location
        		int index = playerPositions.indexOf(playerLoc);
        		// increment the number in that shared location
        		playerCount.set(index, playerCount.get(index) + 1);
 
        		
        	} else {
        		playerCount.add(1);
        		playerPositions.add(playerLoc);
        	}
        }

        for (Player player : board.getPlayers()) {
        	BoardCell playerLoc = board.getCell(player.getRow(), player.getColumn());
        	int index = playerPositions.indexOf(playerLoc);
        	
        	// if there are more than one player in the same room
        	if (playerCount.get(index) > 1) {     		
        		// draw based on the given information
        		player.drawAdjust(graphics, cellWidth, cellHeight, playerCount.get(index));
        		// decrement the number in that shared location
        		playerCount.set(index, playerCount.get(index) - 1);
        	} else { // otherwise draw normally
        		player.draw(graphics, cellWidth, cellHeight);
        	}
        }

        for (Room room : board.getRooms()) {
            // Call drawRoomName for each room to draw the room name at its correct position
            room.drawRoomName(graphics, cellWidth, cellHeight);
        }
        
        // Check if it is the human's turn and draw the target cells if the person has not yet moved
        Player player = board.getPlayerTurn();
        if (player.playerType().equals("Human") && !player.getFinishedTurn()) {
        	HumanPlayer human = (HumanPlayer) player;
        	Set<BoardCell> targets = human.getCurrentTargets();
        	
        	if (targets.size() == 0) {
        		showNoMovesSplash();
        		// handle suggestions
        		handleHumanSuggestions(human);
        	} else if (!human.getMoved()) {
        		Color color = new Color(249, 177, 208);
            	
            	for (BoardCell cell : targets) {
            		cell.draw(graphics, cellWidth, cellHeight, color);
            	}
        	}
        }
    }
    
    public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
	public void mousePressed(MouseEvent e)  {
		// check if it's the human player's turn before doing any actions
		if (board.getPlayerTurn().playerType().equals("Human")) {
			BoardCell cell = null;
			BoardCell[][] boardCells = board.getBoard();
			
			// check every cell for a click
			for (int row = 0; row < numRows; row++) {
	            for (int col = 0; col < numCols; col++) {
	            	if (boardCells[row][col].containsClick(e.getX(), e.getY(), cellWidth, cellHeight)) {
	            		cell = boardCells[row][col];
	            		break;
	            	}
	            }
	        }
			
			// check if the click was on a cell
			if (cell != null) {
				HumanPlayer human = (HumanPlayer) board.getPlayerTurn();
				Set<BoardCell> targets = human.getCurrentTargets();
				Boolean clickedTarget = false;
				
				// check if the cell is part of the targets list
				for (BoardCell target : targets) {
					if (cell == target) {
						clickedTarget = true;
						break;
					}
				}
				
	        	if (!clickedTarget) { // if it is not a valid target, then display an error message
					JOptionPane.showMessageDialog(this, "Not a valid move.");	
				} else { // move the player
					BoardCell lastSpot = board.getCell(human.getRow(), human.getColumn());
					lastSpot.setOccupied(false);
					
					BoardCell newLocation = board.getCell(cell.getRow(), cell.getCol());
					human.setLocation(cell.getRow(), cell.getCol());
					newLocation.setOccupied(true);
					repaint(); // update the visuals
					human.setMoved(true);
					
					// check if the target cell is in a room (not a walkway)
					if (!cell.getCellRoom().getName().equals("Walkway")) {
						// handle suggestions
						handleHumanSuggestions(human);
					}
					
					// set the turn to finish
					human.setFinishedTurn(true);
				}
			}
		}	
		
	}	
	
	 private void showNoMovesSplash() {
        // Display the splash screen with the message
        JOptionPane.showMessageDialog(this,
                "Oh no! You have no valid moves this turn."); 
	 }
	 
	 private void handleHumanSuggestions(HumanPlayer human) {
		// use JComboBoxes to get the suggestion from the human player and store it in an attribute
		JLabel roomLabel = new JLabel("Current room");
		JLabel personLabel = new JLabel("Person");
		JLabel weaponLabel = new JLabel("Weapon");

		// text label for the current room
		room = board.getCell(human.getRow(), human.getColumn()).getCellRoom().getName();
		JTextField roomText = new JTextField(room); 
		roomText.setEditable(false);

		// put all persons as an option
		ArrayList<Player> players = board.getPlayers();
		personCombo = new JComboBox<String>();
		for (Player player : players) {
			personCombo.addItem(player.getName());
		}

		// put all weapons as an option
		ArrayList<Card> weaponCards = board.getWeaponCards();
		weaponCombo = new JComboBox<String>();
		for (Card card : weaponCards) {
			weaponCombo.addItem(card.getName());
		}
		
		// put in a JPanel to put into a JOptionPane
		JPanel suggestion = new JPanel();
		suggestion.setLayout(new GridLayout(3, 2));
		
		// add them to the panel
		suggestion.add(roomLabel);
		suggestion.add(roomText);
		suggestion.add(personLabel);
		suggestion.add(personCombo);
		suggestion.add(weaponLabel);
		suggestion.add(weaponCombo);
		
		// now add the panel to the option pane
		int result = JOptionPane.showConfirmDialog(this, suggestion, "Make a suggestion.", JOptionPane.OK_CANCEL_OPTION);
		
		// grab the inputs from the user		
		// check whether the user has selected OK or Cancel
		if (result == JOptionPane.OK_OPTION) {
			// retrieve the final choices from the JComboBoxes
		    character = personCombo.getSelectedItem().toString();
		    weapon = weaponCombo.getSelectedItem().toString();
		    
		    // handle suggestions
		    board.humanSuggestions();
		} else { // if it was cancelled, pull up the option pane again
			JOptionPane.showMessageDialog(this, "Please make a suggestion.");
			handleHumanSuggestions(human);
		}
	 }
	 
	 public void handleHumanAccusation() {
			// use JComboBoxes to get the suggestion from the human player and store it in an attribute
	    	Board board = Board.getInstance();
			JLabel roomLabel = new JLabel("Room");
			JLabel personLabel = new JLabel("Person");
			JLabel weaponLabel = new JLabel("Weapon");


			ArrayList<Card> roomCards = board.getRoomCards();
			roomCombo = new JComboBox<String>();
			for(Card card : roomCards) {
				roomCombo.addItem(card.getName());
			}

			// put all persons as an option
			ArrayList<Player> players = board.getPlayers();
			personCombo = new JComboBox<String>();
			for (Player player : players) {
				personCombo.addItem(player.getName());
			}

			// put all weapons as an option
			ArrayList<Card> weaponCards = board.getWeaponCards();
			weaponCombo = new JComboBox<String>();
			for (Card card : weaponCards) {
				weaponCombo.addItem(card.getName());
			}
			
			// put in a JPanel to put into a JOptionPane
			JPanel accusation = new JPanel();
			accusation.setLayout(new GridLayout(3, 2));
			
			// add them to the panel
			accusation.add(roomLabel);
			accusation.add(roomCombo);
			accusation.add(personLabel);
			accusation.add(personCombo);
			accusation.add(weaponLabel);
			accusation.add(weaponCombo);
			
			// now add the panel to the option pane
			int result = JOptionPane.showConfirmDialog(null, accusation, "Make an accusation.", JOptionPane.OK_CANCEL_OPTION);
			
			// grab the inputs from the user		
			// check whether the user has selected OK or Cancel
			if (result == JOptionPane.OK_OPTION) {
				// retrieve the final choices from the JComboBoxes
				String room = roomCombo.getSelectedItem().toString();
			    String character = personCombo.getSelectedItem().toString();
			    String weapon = weaponCombo.getSelectedItem().toString();
			    
			    
			    Card roomCard = board.getCardFromName(room);
			    Card characterCard = board.getCardFromName(character);
			    Card weaponCard = board.getCardFromName(weapon);
			    // handle suggestions
			    board.makeAccusation(roomCard, characterCard, weaponCard);
			    board.humanAccusations();
			} 
		 }
    
    // getters
    public int getCellWidth() {
    	int panelWidth = getWidth();
    	cellWidth = panelWidth / numCols;
    	
    	return cellWidth;
    }

    public int getCellHeight() {
    	int panelHeight = getHeight();
    	cellHeight = panelHeight / numRows;
    	
    	return cellHeight;
    }
    
    public String getCharacter() {
    	return character;
    }
    
    public String getWeapon() {
    	return weapon;
    }
    
    public String getRoom() {
    	return room;
    }
    
    public static void main(String[] args) {
        // Create the frame and set up window
        JFrame frame = new JFrame("Clue Game Board");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Initialize the BoardPanel and add it to the frame
        BoardPanel boardPanel = new BoardPanel();
        frame.add(boardPanel, BorderLayout.CENTER);
        
        // Set size for the frame and make it visible
        frame.setSize(800, 800);  
        frame.setLocationRelativeTo(null);  
        frame.setVisible(true);
    }
}
