/**
 * BadConfigFormat Exception -- custom exception thrown when the config files are not correct
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/11/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

public class BadConfigFormatException extends Exception {
	
    public BadConfigFormatException(String message) {
        super(message);
    }
    
    public BadConfigFormatException() {
        super("The configuration files are in the wrong format");
    }
    
}
