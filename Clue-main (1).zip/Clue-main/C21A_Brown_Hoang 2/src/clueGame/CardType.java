/**
 * CardType -- is the enum type for the cards
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

public enum CardType {
	ROOM, 
    WEAPON,
    CHARACTER
}
