/**
 * Card -- contains the Clue game's cards
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;
import java.util.Objects;

public class Card {
	String cardName;
	CardType cardType;
	
	public Card() {
		super();
	}
	
	public Card(String name, CardType cardType) {
		this.cardName = name;
		this.cardType = cardType;
	}

	// getters
    public CardType getCardType() {
    	return cardType;
    }
    
    public String getName() {
    	return cardName;
    }

    // equals() method -- created by Eclipse
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Card other = (Card) obj;
		return Objects.equals(cardName, other.cardName) && cardType == other.cardType;
	}

	@Override
	public String toString() {
		return "Card Name: " + cardName + "\nCard Type: " + cardType;
	}
}
