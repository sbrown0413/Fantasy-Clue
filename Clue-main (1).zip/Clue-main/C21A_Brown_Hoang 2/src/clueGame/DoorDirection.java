/**
 * DoorDirection -- enum for the types of door direction
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/11/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

public enum DoorDirection {
    UP, DOWN, RIGHT, LEFT, NONE;
}
