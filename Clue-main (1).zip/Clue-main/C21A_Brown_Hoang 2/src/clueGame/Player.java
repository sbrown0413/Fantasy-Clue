/**
 * Player -- contains the players for the Clue Game
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;
import java.util.Random;

public abstract class Player {
	private String name;
	private String color;
	private int row;
	private int column;
	private ArrayList<Card> hand;
    private ArrayList<Card> seen;
	private Solution suggestion;

    
    public Player(String name, String color, int row, int col) {
        this.name = name;
        this.color = color;
        this.row = row;
        this.column = col;
        hand = new ArrayList<Card>();
        seen = new ArrayList<Card>();
    }
    
    public Card disproveSuggestion(Solution otherSuggestion) {
        ArrayList<Card> matches = new ArrayList<Card>();
        // check if the player's hand contains any of the suggestion cards, otherwise return null
        Card room = otherSuggestion.getRoom();
        Card person = otherSuggestion.getPerson();
        Card weapon = otherSuggestion.getWeapon();

    	if (hand.contains(room)) {
            matches.add(room);
        } 
        if (hand.contains(person)) {
            matches.add(person); 
        }
        if (hand.contains(weapon)) {
            matches.add(weapon);
        }
        if (matches.size() > 0) {
            Random random = new Random();
            int index = random.nextInt(matches.size());
            return matches.get(index);
        }
        // otherwise return null if there are no matches
        return null;
    }

    // clear the player's hand (for testing purposes)
    public void clearHand() {
        hand.clear();
        seen.clear();
    }
    
    // setters
    public void addToHand(Card card) {
    	hand.add(card);
        seen.add(card);
    }
    
    public void setSuggestion(Card card1, Card card2, Card card3) {
    	suggestion = new Solution(card1, card2, card3);
    }

    public void addSeen(Card card) {
        if (!seen.contains(card)) {
            seen.add(card);
        }
    }

    public void setLocation(int row, int col) {
        this.row = row;
        this.column = col;
    }
    
    // getters
    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public int getRow() {
    	return row;
    }
    
    public int getColumn() {
    	return column;
    }
    
    public ArrayList<Card> getHand() {
    	return hand;
    }

    public Solution getSuggestion() {
        return suggestion;
    }
    
    public ArrayList<Card> getUnseenCards() {
    	ArrayList<Card> unseen = new ArrayList<Card>();
    	
    	Board board = Board.getInstance();
		ArrayList<Card> deck = board.getDeckCards();
		for(Card cardDeck: deck) {
			boolean inSeen = false;
			for(Card cardSeen: seen) {
				if(cardSeen.equals(cardDeck)) {
					inSeen = true;
				}
			}
			if(!inSeen) {
				unseen.add(cardDeck);
			}
		}
		return unseen;
	}
    
    
    // an abstract method to determine which child class the player was implemented as
    public abstract String playerType();
}
