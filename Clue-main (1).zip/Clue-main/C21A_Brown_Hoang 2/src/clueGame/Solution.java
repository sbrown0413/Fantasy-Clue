/**
 * Solution -- contains the Clue game's final answer
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

public class Solution {
	private Card room;
	private Card person;
	private Card weapon;
	
	public Solution() {
		super();
	}

	public Solution(Card card1, Card card2, Card card3) {
		switch(card1.getCardType()) {
			case ROOM:
				this.room = card1;
				break;
			case CHARACTER:
				this.person = card1;
				break;
			case WEAPON:
				this.weapon = card1;
				break;
		}
		switch(card2.getCardType()) {
			case ROOM:
				this.room = card2;
				break;
			case CHARACTER:
				this.person = card2;
				break;
			case WEAPON:
				this.weapon = card2;
				break;
		}
		switch(card3.getCardType()) {
			case ROOM:
				this.room = card3;
				break;
			case CHARACTER:
				this.person = card3;
				break;
			case WEAPON:
				this.weapon = card3;
				break;
		}
	}
	
	// setters
	public void setRoomCard(Card room) {
		this.room = room;
	}
	
	public void setPlayerCard(Card player) {
		this.person = player;
	}
	
	public void setWeaponCard(Card weapon) {
		this.weapon = weapon;
	}
	
	// getters
	public Card getRoom() {
		return room;
	}

	public Card getPerson() {
		return person;
	}

	public Card getWeapon() {
		return weapon;
	}	
}
