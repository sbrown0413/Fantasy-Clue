/**
 * BoardCell -- a representation of a board cell in the Clue game grid
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/11/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.Set;
import java.util.HashSet;

public class BoardCell {
    private int row;
    private int col;
    private Set<BoardCell> adjList;
    private boolean isRoom;
    private boolean isOccupied;
    private boolean doorway;
    private boolean label;
    private boolean roomCenter;
    private boolean isSecretPassage;
    private char secretPassage;
    private DoorDirection doorDirection;
    private Room room;

    // Constructor
    public BoardCell(int row, int col) {
        this.row = row;
        this.col = col;
        adjList = new HashSet<BoardCell>();
    }
    
    /*
     * Add a cell to this cell's adjacency list
     */
    public void addAdjacency(BoardCell cell) {
    	adjList.add(cell);
    }

    /*
     * Returns the adjacency list for the cell	
     */
    public Set<BoardCell> getAdjListCell() {
        return adjList;
    }
    
    /*
     * returns door direction
     */
    public DoorDirection getDoorDirection() {
    	return doorDirection;
    }

    // returns the boolean value of its corresponding variable
    public boolean isDoorway() {
        return doorway;
    }
    
    public boolean isLabel() {
        return label;
    }
    
    public boolean isRoomCenter() {
        return roomCenter;
    }

    public boolean checkSecretPassage() {
        return isSecretPassage;
    }
    
    // setters
    public void setRoom(boolean isRoom) {
        this.isRoom = isRoom;
    }
    
    public void setOccupied(boolean isOccupied) {
    	this.isOccupied = isOccupied;
    }
    
    public void setDoorDirection(DoorDirection doorDirection) {
        this.doorDirection = doorDirection;    
    }
    
    public void setSecretPassage(char secretPassage) {
    	this.secretPassage = secretPassage;
        isSecretPassage = true;
    }
    
    public void setDoorway(boolean doorway) {
        this.doorway = doorway;
    }
    
    public void setRoomCenter(boolean roomCenter) {
        this.roomCenter = roomCenter;
    }
    
    public void setCellRoom(Room room) {
        this.room = room;
    }
    
    public void setLabel(boolean label) {
        this.label = label;
    }
    
    // getters
    public boolean getRoom() {
    	return isRoom;
    }
    
    public boolean getOccupied() {
        return isOccupied;
    }
    
    public Room getCellRoom() {
        return room;
    }
    
    public char getSecretPassage() {
        return secretPassage;
    }

    @Override
    public String toString() {
        return "(" + row + ", " + col + ")";
    }
}