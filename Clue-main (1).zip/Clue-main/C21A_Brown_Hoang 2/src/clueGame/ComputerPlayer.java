/**
 * ComputerPlayer -- the players that will be controlled by the algorithm
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;
import java.util.Random;
import java.util.Set;

public class ComputerPlayer extends Player {
	private String type = "Computer";

	
	public ComputerPlayer(String name, String color, int row, int col)  {
        super(name, color, row, col); 
    }

	public String playerType() {
		return type;
	}
	
	public Solution createSuggestion(BoardCell location) {
		// the suggestion must have the card of the current room
		Room currentRoom = location.getCellRoom();
		Card room = new Card(currentRoom.getName(), CardType.ROOM);

		ArrayList<Card> unseen = getUnseenCards();
		Random random = new Random();
		ArrayList<Card> unseenWeapons = new ArrayList<Card>();
		ArrayList<Card> unseenPersons = new ArrayList<Card>();

		for (Card card : unseen) {
			switch (card.getCardType()) {
				case WEAPON:
					unseenWeapons.add(card);
					break;
				case CHARACTER:
					unseenPersons.add(card);
					break;
			}
		}

		// the suggestion will ensure a weapon that has not been seen is randomly chosen
		int randomWeapon = random.nextInt(unseenWeapons.size());
		Card weapon = unseenWeapons.get(randomWeapon);
		// the suggestion will ensure a person that has not been seen is randomly chosen
		int randomPerson = random.nextInt(unseenPersons.size());
		Card person = unseenPersons.get(randomPerson);

		return new Solution(room, weapon, person);
	}
	
	public BoardCell selectTarget(Set<BoardCell> targets) {
		ArrayList<Card> unseenRooms = new ArrayList<Card>();
		ArrayList<Card> unseen = getUnseenCards();
		for (Card card : unseen) {
			if (card.getCardType() == CardType.ROOM) {
				unseenRooms.add(card);
			}
		}
		
		ArrayList<BoardCell> roomOptions = new ArrayList<BoardCell>();
		
		// if one of the targets is a room that we haven't seen, then choose that one
		for (BoardCell cell : targets) {
			Room currentRoom = cell.getCellRoom();
			// if the target is not a walkway, then it is a room
			if (!currentRoom.getName().equals("Walkway")) {
				String roomName = currentRoom.getName();
				Card room = new Card(roomName, CardType.ROOM);
				if (unseenRooms.contains(room)) {
					roomOptions.add(cell);
				}
			}
		}
		
		Random random = new Random();
		// return a random unseen room if there were any

		if (roomOptions.size() > 0) {
			int randRoom = random.nextInt(roomOptions.size());			
			return roomOptions.get(randRoom);
		}		

		// otherwise, choose a random cell
		int randIndex = random.nextInt(targets.size());
		Object[] targetsArray = targets.toArray();
		return (BoardCell) targetsArray[randIndex];
	}
	
}
