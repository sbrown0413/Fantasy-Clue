/**
 * HumanPlayer -- the players that will be controlled by the user
 * Authors: Summer Brown and Kairi Hoang
 * Date: 11/2/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

public class HumanPlayer extends Player {
	private String type = "Human";
	
	public HumanPlayer(String name, String color, int row, int col)  {
        super(name, color, row, col);
    }
	
	public String playerType() {
		return type;
	}
}
