/**
 * Board -- the Clue game board 
 * Authors: Kairi Hoang and Summer Brown
 * Collaborators: None
 * Sources: 
 * https://stackoverflow.com/questions/12130776/slice-string-in-java
 * https://www.geeksforgeeks.org/how-to-find-length-or-size-of-an-array-in-java/
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/trim
 * https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/#
 * https://www.javatpoint.com/java-string-to-char
 * https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/
 * https://www.w3schools.com/java/java_switch.asp
 */
package clueGame;

import java.util.Set;

import java.util.HashSet;
import java.io.FileReader;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Board {
    private BoardCell[][] board;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	private boolean calcDone;
	private int cols;
	private int rows;
	private String layout;
	private String setup;
	private Map<Character, Room> roomKey;
	private ArrayList<ArrayList<String>> entireBoard;
	private ArrayList<Player> players;
	private ArrayList<Card> weaponCards;
	private ArrayList<Card> playerCards;
	private ArrayList<Card> roomCards;
	private ArrayList<Card> deckCards;
	private Card[] solution;
	private Card[] accusation;
	private Solution answer;
	private Map<Player, ArrayList<Card>> playerHands;
	
		
	private static Board theInstance = new Board(); // variable used for singleton pattern
     
     // constructor is private to ensure only one can be created
     private Board() { 
 		super();
    }
     
     // this method returns the only Board
     public static Board getInstance() {
    	return theInstance;
    }
     
     /**
      * initialize the board (since we are using singleton pattern)
      */
     public void initialize() {	
    	visited = new HashSet<BoardCell>();
   		targets = new HashSet<BoardCell>();
  		players = new ArrayList<Player>();
  		deckCards = new ArrayList<Card>();
  		solution = new Card[3];
  		accusation = new Card[3];
  		answer = new Solution();
  		playerHands = new HashMap<Player, ArrayList<Card>>();
  		calcDone = false;
		// read in the setup file and initialize the hashmap with the corresponding room characters
		// read in the layout csv and check if the file as written correctly
		// also store the values from the csv into the entireBoard instance variable
		try {
			loadSetupConfig();
			loadLayoutConfig();
		} catch (BadConfigFormatException e) {
			System.out.println(e.getLocalizedMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		}
		
		// initialize the board
		board = new BoardCell[rows][cols];

		// put a cell in all of the board units	
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				// grab the value stored in this cell location
				String cell = entireBoard.get(row).get(col);
				// the initialize the current cell that is being looked at
				BoardCell boardCell = new BoardCell(row, col);
				board[row][col] = boardCell;

				// grab the character that defines the room
				char roomType = cell.charAt(0);
				char cellType = ' ';

				// create a room for every board cell
				Room currentRoom = roomKey.get(roomType);
				currentRoom.setRoomCell(boardCell);
				boardCell.setCellRoom(currentRoom);				
				
				// Sees if cell is a special cell
				if(cell.length() > 1) {
					cellType = cell.charAt(1);
				}
				
				switch (cellType) {
			    case '<':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.LEFT);
			        break;
			    case '>':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.RIGHT);
			        break;
			    case '^':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.UP);
			        break;
			    case 'v':
			        boardCell.setDoorway(true);
			        boardCell.setDoorDirection(DoorDirection.DOWN);
			        break;
			    case '*': // Check if the cell is a room center
			        boardCell.setRoomCenter(true);
			        currentRoom.setCenterCell(boardCell);
			        boardCell.setDoorDirection(DoorDirection.NONE);
			        break;
			    case '#': // Check if the cell is a room label
			        boardCell.setLabel(true);
			        currentRoom.setLabelCell(boardCell);
			        boardCell.setDoorDirection(DoorDirection.NONE);
			        break;
			    default:
			        if (roomKey.containsKey(cellType)) { // Check if the cell is a secret passage
			            boardCell.setSecretPassage(cellType);
			            currentRoom.setSecretPassageCell(boardCell);
				        boardCell.setDoorDirection(DoorDirection.NONE);
			        }
			        break;
				}
			}
		}

		// find the adjacencies of the cells
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				BoardCell boardCell = board[row][col];
				findAdjacencies(boardCell, row, col);
			}			
		}
		
		int totalCards = roomCards.size() + playerCards.size() + weaponCards.size();
		if (roomCards.size() > 0 && playerCards.size() > 0 && weaponCards.size() > 0) {
			shuffleCards(totalCards);
		}
}
	
	/**
	 * Calculates the legal targets for a move from startCell of length pathLength
	 * @param startCell starting cell that we will move from
	 * @param pathlength length of a path
	 */
	public void calcTargets(BoardCell startCell, int pathlength) {
		// once we get the targets value, then we need to reset the array lists
		if (calcDone) {
			visited.clear();
			targets.clear();
			calcDone = false;
		}
		
		Set<BoardCell> adjList = startCell.getAdjListCell();
		// add the current cell to the visited list
		visited.add(startCell);
		
		// go through the adjacent cells
		for(BoardCell adjCell : adjList) {
			// check if the adjacent cell has not been visited and is not occupied unless it's a room (rooms can be occupied and still be gone in)
			if ((!visited.contains(adjCell) && !adjCell.getOccupied()) || (!visited.contains(adjCell) && adjCell.isRoomCenter())) {
				
				visited.add(adjCell);
				if(pathlength == 1) {
					targets.add(adjCell);
				} else if (adjCell.isRoomCenter()) {
					targets.add(adjCell);
				} else {
					calcTargets(adjCell, pathlength - 1);
				}
				visited.remove(adjCell);
			} 
		}	
	}
	
	/**
	 * Take the setup file and unpack it in terms of the program
	 * @throws BadConfigFormatException
	 * @throws FileNotFoundException
	 */
	public void loadSetupConfig() throws BadConfigFormatException, FileNotFoundException {
		// initialize the card arrays
  		weaponCards = new ArrayList<Card>();
  		playerCards = new ArrayList<Card>();
  		roomCards = new ArrayList<Card>();
  		
		// open the file and read from that file
		FileReader reader = new FileReader(setup);
		Scanner in = new Scanner(reader); //Why warning
		
		// This will store the letter as the key and room name as the value
		roomKey = new HashMap<>();
		
		// Reading in lines
		while (in.hasNextLine()) {
			// Gets rid of spaces
			String line = in.nextLine().trim(); 
			
			// Ignores comments
			if (line.startsWith("//")) {
                continue;
            }

			// Splits at commas
			String[] sections = line.split(",");
			String type = sections[0].trim();
			
			
			// Check the formatting of the file
			switch(type) {
				case "Room", "Space":
					if (sections.length != 3) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Room or Space. Needs 3 sections.");
					}
					String name = sections[1].trim();
					char identifier = sections[2].trim().charAt(0);
					
					// create a room with the given information
					Room room = new Room(name);
					// store it into the hashtable
					roomKey.put(identifier, room);
					
					// create the room cards and add it to the roomCards array list
					if (type.equals("Room")) {
						Card roomCard = new Card(name, CardType.ROOM);
						roomCards.add(roomCard);
					}
					break;
				case "Player":
					if (sections.length != 6) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Player. Needs 6 sections.");
					}	
					name = sections[1].trim();
					String color = sections[2].trim();
					String playerType = sections[3].trim();
					int x = Integer.parseInt(sections[4].trim());
					int y = Integer.parseInt(sections[5].trim());
					// create the players with the given information
					Player player;
					if (playerType.equals("Human")) {
						player = new HumanPlayer(name, color, x, y);
					} else {
						player = new ComputerPlayer(name, color, x, y);
					}
					
					// add it to the players ArrayList
					players.add(player);
					
					// create the player cards and add it to the playerCards array list
					Card playerCard = new Card(name, CardType.CHARACTER);
					playerCards.add(playerCard);
					break;
				case "Weapon":
					if (sections.length != 2) {
						throw new BadConfigFormatException("Contains " + sections.length + " sections for Weapon. Needs 2 sections.");
					}
					String weaponType = sections[1].trim();
					
					// create the weapon cards and add it to the weaponCards array list
					Card weaponCard = new Card(weaponType, CardType.WEAPON);
					weaponCards.add(weaponCard);
					break;
				default: // Should ONLY have rooms, spaces, players, and weapons
					throw new BadConfigFormatException("Setup.txt is formatted wrong.");
			}
		}
		// close the file
		in.close();
	} 
	
	/**
	* Loads in the config files and builds the board
	*/
	public void loadLayoutConfig() throws BadConfigFormatException, FileNotFoundException {
		// open the file and read from that file
		entireBoard = new ArrayList<>(); // holds each rows
		FileReader reader = new FileReader(layout);
		Scanner in = new Scanner(reader);	
	
		while (in.hasNextLine()) {
			ArrayList<String> eachRow = new ArrayList<>();
			String line = in.nextLine();
			
			// put the board characters into an array, split based on the commas
			String[] cells = line.split(",");
			
			// add the separated strings into the inner list
			for (String cell : cells) {
				cell = cell.trim();

				// if the cell is empty, then there's a bad format
				if (cell.isEmpty()) {
					in.close();
					throw new BadConfigFormatException("The layout file has missing values.");
				}
				
				// get the first character from the cell
				char room = cell.charAt(0);				
				
				if (roomKey.containsKey(room)) {
					eachRow.add(cell);	
				}
  			 	// otherwise, that cell character is undefined
				else {
					in.close();
					throw new BadConfigFormatException("The layout file contains undefined characters: " + room);
				}
			}
			// then add the inner list to the outer list
			entireBoard.add(eachRow);		
		}		
		in.close();

		// the number of rows equals the number of inner lists made
		rows = entireBoard.size();
		int prevCol = entireBoard.get(0).size();

		// loop through the ArrayLists and check if the column sizes stay consistent, otherwise throw a BadConfigFormatException
		for (int row = 1; row < rows; row++) {
			int currCol = entireBoard.get(row).size();
			if (currCol != prevCol) {
				throw new BadConfigFormatException("The layout file does not have a consist number of columns.");
			}
		}
		
		// store the number of columns in the instance variable as long as we have more than one row
		if (rows != 0) {
			// the number of columns equal to the number of values within each inner list
			cols = entireBoard.get(0).size(); 
		} else {
			cols = 0;
			throw new BadConfigFormatException("The layout file does not contain any information");
		}		
	}
		
	/**
	 * Finds the adjacent cells at a certain board cell and stores them in adjList
	 * @param cell
	 * @param row
	 * @param col
	 */
	public void findAdjacencies(BoardCell cell, int row, int col) {
		int right = col + 1;
		int left = col - 1;
		int up = row - 1;
		int down = row + 1;

		Room currentRoom = cell.getCellRoom();

		// if cell is Doorway (must look at corresponding room coordinates, and find said room in the hash map values the key will tell us what room it is, and if it is a walkway or unused space)
		if (cell.isDoorway()) {
			BoardCell adjCell;
			Room adjRoom = currentRoom; // has to be initialized to a room, but will always get assigned to the correct room after the switch case statements
			
			// Get the door direction
			switch(cell.getDoorDirection()) {
				case RIGHT:
					adjCell = getCell(row, right);
					adjRoom = adjCell.getCellRoom();
					break;
				case LEFT:
					adjCell = getCell(row, left);
					adjRoom = adjCell.getCellRoom();
					break;
				case UP:
					adjCell = getCell(up, col);
					adjRoom = adjCell.getCellRoom();
					break;
				case DOWN:
					adjCell = getCell(down, col);
					adjRoom = adjCell.getCellRoom();
					break;
			}
			
			BoardCell center = adjRoom.getCenterCell();
			// add the adjacent cell's room center to the door adjacencies
			cell.addAdjacency(center);

			// add the door as an adjacent cell to the room center
			center.addAdjacency(cell);	
			
		} else if (cell.isRoomCenter()) { // check if the cell is a room center
			// room centers are adjacent to secret passageways and doorways (no other cells)
			// the adjacent doorways will be added when we look for the adjacent room centers for doors (above)
			
			ArrayList<BoardCell> roomCell = currentRoom.getRoomCell();
			
			// iterate through the room cells and check if they have a secret passage
			for (BoardCell checkCell : roomCell) {
				if (checkCell.checkSecretPassage()) {
					char secretRoomKey = checkCell.getSecretPassage();
					Room secretRoom = roomKey.get(secretRoomKey);
					
					// Add centers of room connected through secret passage ways
					cell.addAdjacency(secretRoom.getCenterCell());
				}
			}		
		} 
		// check if the cell is a walkway or if it was a doorway and add their adjacent walkways
		if (currentRoom.getName().equals("Walkway") || cell.isDoorway()) { 
			addWalkwayAdj(cell, row, left);
			addWalkwayAdj(cell, row, right);
			addWalkwayAdj(cell, up, col);
			addWalkwayAdj(cell, down, col);
		}
	}
	
	/**
	 * Add the adjacent walkway to the current cell
	 * @param cell: current cell
	 * @param adjRow: adjacent row location
	 * @param adjCol: adjacent col location
	 */
	public void addWalkwayAdj(BoardCell cell, int adjRow, int adjCol) {
		// check boundaries
		if (adjRow >= 0 && adjRow < rows && adjCol >= 0 && adjCol < cols) {
			BoardCell adjCell = board[adjRow][adjCol];
			Room adjRoom = adjCell.getCellRoom();
			
			// Check if it is an unoccupied walkway and add the adjacent cell
			if (adjRoom.getName().equals("Walkway") && !adjCell.getOccupied()) {
				cell.addAdjacency(adjCell);
			}
		}
	}
	
	public void shuffleCards(int totalCards) {
		ArrayList<Card> shuffled = new ArrayList<Card>();
		
		// create the solution by putting a random room card, player card, and weapon card
		Random random = new Random();
		
		// generate a random index for the room cards, get the corresponding card and put it in the solution
		int randomCardIndex = random.nextInt(roomCards.size());
		Card randomCard = roomCards.get(randomCardIndex);
		solution[0] = randomCard;
		answer.setRoomCard(randomCard);
		// add this to the deck for the beginning cards that won't be looked at
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;

		randomCardIndex = random.nextInt(playerCards.size());
		randomCard = playerCards.get(randomCardIndex);
		solution[1] = randomCard;
		answer.setPlayerCard(randomCard);
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;
		
		randomCardIndex = random.nextInt(weaponCards.size());
		randomCard = weaponCards.get(randomCardIndex);
		solution[2] = randomCard;
		answer.setWeaponCard(randomCard);
		shuffled.add(randomCard);
		deckCards.remove(randomCard);
		totalCards--;
		
		// put all of the cards in the deck of cards
		for (Card card : roomCards) {
			deckCards.add(card);
		}
		
		for (Card card : playerCards) {
			deckCards.add(card);
		}
		
		for (Card card : weaponCards) {
			deckCards.add(card);
		}

		// shuffle the deck
		while (deckCards.size() > 0) {
			int randomIndex = random.nextInt(deckCards.size());
			Card shuffledCard = deckCards.get(randomIndex);
			if (!shuffled.contains(shuffledCard)) {
				shuffled.add(shuffledCard);
				deckCards.remove(shuffledCard);
				totalCards--;
			} else {
				deckCards.remove(shuffledCard);
			}
		}

		// now set the deck to the shuffled deck
		deckCards = shuffled;
		
		// deal the remaining cards to the players
		int skip = 3;
		int dealPlayer = 0;
		for (Card card : deckCards) {
			// skip the first three cards 
			if (skip > 0) {
				skip--;
				continue;
			}
			
			// if the rotation is past the last player in the array list, start over from the first index		
			// add the card to the next player's hand
			players.get(dealPlayer % players.size()).addToHand(card);
			dealPlayer++;
		}
		
		// put each player and their hands into the hashmap
		for (Player player : players) {
			playerHands.put(player, player.getHand());
		}
	}
	
	public void makeAccusation(Card weapon, Card character, Card room) {
		accusation[0] = room;
		accusation[1] = character;
		accusation[2] = weapon;
	}
	
	public boolean checkAccusation() {
		if (accusation[0].equals(solution[0]) && accusation[1].equals(solution[1]) && accusation[2].equals(solution[2])) {
			return true;
		}
		return false;
	}

	public Card handleSuggestion(Solution suggestion, Player playerSuggest) {	
		for (Player player : players) {
			if (player == playerSuggest) {
				continue;
			}
			Card card = player.disproveSuggestion(suggestion);
			if (card != null) {
				player.addSeen(card);
				return card;
			}
		}
		return null;
	}

	// setters
	public void setConfigFiles(String csv, String txt) {
		layout = "data/" + csv;
		setup = "data/" + txt;
	}
	
	public Card[] setSolution(Card weapon, Card character, Card room) {
		solution[0] = room;
		solution[1] = character;
		solution[2] = weapon;
		return solution;
	}
	
	public Set<BoardCell> getTargets() {	
		calcDone = true;
		return targets;
	}
	
	public Set<BoardCell> getAdjList(int row, int col) {
		BoardCell cell = getCell(row, col);
		Set<BoardCell> adjList = cell.getAdjListCell();
		return adjList;
	}
	
	public void setPlayers(ArrayList<Player> newPlayers) {//
		players.clear();
		players = newPlayers;
	}
	
	
	// getters
	public BoardCell getCell(int row, int col) {
		return board[row][col];
	}
	
	public Room getRoom(char roomRep) {
		return roomKey.get(roomRep);
	}

	public Room getRoom(BoardCell cell) {
		return cell.getCellRoom();
	}

	public int getNumRows() {
		return rows;
	}

	public int getNumColumns() {
		return cols;
	}

	public ArrayList<Player> getPlayers() {
        return players;
    }
	
	public ArrayList<Card> getRoomCards() {
		return roomCards;
	}
	
	public ArrayList<Card> getWeaponCards() {
		return weaponCards;
	}
	
	public ArrayList<Card> getPlayerCards() {
		return playerCards;
	}
	
	public ArrayList<Card> getDeckCards() {
		return deckCards;
	}
	
	public Card[] getSolution() {
		return solution;
	}
	
	public Map<Player, ArrayList<Card>> getPlayerHands() {
		return playerHands;
	}
	
	public Card[] getAccusation() {
		return accusation;
	}
}