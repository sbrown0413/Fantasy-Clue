/**
 * Room -- contains a cell's room information
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/11/24
 * Collaborators: None
 * Sources: None
 */
package clueGame;

import java.util.ArrayList;

public class Room {
    private ArrayList<BoardCell> roomCell;
    private BoardCell centerCell;
    private BoardCell labelCell;
    private BoardCell secretPassageCell;
    private String name;

    public Room(String name) {
    	roomCell = new ArrayList<BoardCell>();
    	this.name = name;
    }
    
    // setters
    public void setName(String newName) {
    	this.name = newName;
    }
    
    public void setRoomCell(BoardCell cell) {
    	roomCell.add(cell);
    }
    
    public void setCenterCell(BoardCell cell) {
        this.centerCell = cell;
    }
    
    public void setLabelCell(BoardCell cell) {
    	this.labelCell = cell;
    }
    
    public void setSecretPassageCell(BoardCell cell) {
    	this.secretPassageCell = cell;
    }
    
    // getters
    public String getName() {
        return name;
    }
    
    public ArrayList<BoardCell> getRoomCell() {
        return roomCell;
    }

    public BoardCell getCenterCell() {
      return centerCell;
    }
    
    public BoardCell getLabelCell() {
    	return labelCell;
    }
    
    public BoardCell getSecretPassageCell() {
    	return secretPassageCell;
    }
}
