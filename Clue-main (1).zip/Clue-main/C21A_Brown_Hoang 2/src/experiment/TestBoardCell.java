/**
 * TestBoardCell -- a representation of a board cell in the Clue game grid
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/7/24
 * Collaborators: None
 * Sources: https://www.w3schools.com/java/java_hashset.asp and https://www.geeksforgeeks.org/hashset-in-java/
 */
package experiment;

import java.util.Set;
import java.util.HashSet;

public class TestBoardCell {
    private int row;
    private int col;
    private Set<TestBoardCell> adjList;
    private boolean isRoom;
    private boolean isOccupied; 

    /*
     * Constructor
     */
    public TestBoardCell(int row, int col) {
        this.row = row;
        this.col = col;
        adjList = new HashSet<TestBoardCell>();
    }
    
    /*
     * A setter to add a cell to this cell's adjacency list
     */
    public void addAdjacency(TestBoardCell cell) {
    	adjList.add(cell);
    }

    /*
     * returns the adjacency list for the cell	
     */
    public Set<TestBoardCell> getAdjList() {
        return adjList;
    }

    /*
     * indicating a cell is part of a room
     */
    public void setRoom(boolean isRoom) {
        this.isRoom = isRoom;
    }

    /*
     * indicating a cell is part of a room
     */
    public boolean isRoom() {
    	return isRoom;
    }

    /*
     * indicating a cell is occupied by another player 
     */
    public void setOccupied(boolean isOccupied) {
    	this.isOccupied = isOccupied;
    }

    /*
     * indicating a cell is occupied by another player 
     */
    public boolean getOccupied() {
        return isOccupied;
    }
   
}
