/**
 * TestBoard -- the Clue game board
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/7/24
 * Collaborators: None
 * Sources: None
 */
package experiment;

import java.util.Set;
import java.util.HashSet;

public class TestBoard {
	private TestBoardCell[][] grid;
	private Set<TestBoardCell> targets;
	private Set<TestBoardCell> visited;
	final static int COLS = 4;
	final static int ROWS = 4;
    
	public TestBoard() {
		grid = new TestBoardCell[ROWS][COLS];
		visited = new HashSet<TestBoardCell>();
		targets = new HashSet<TestBoardCell>();

		
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				// put a cell into the board
				grid[row][col] = new TestBoardCell(row, col);
			}
		}
		
		for (int row = 0; row < ROWS; row++) {
			for (int col = 0; col < COLS; col++) {
				TestBoardCell cell = grid[row][col];
				// each cell will have to have a neighbor
				// check if it's not the edge
				if (row > 0 && row < (ROWS - 1)) {
					cell.addAdjacency(getCell(row - 1, col));
					cell.addAdjacency(getCell(row + 1, col));
				} else if (row == 0) { // otherwise, it is an edge
					cell.addAdjacency(getCell(row + 1, col));
				} else if (row == ROWS - 1) {
					cell.addAdjacency(getCell(row - 1, col));
				}
				
				if (col > 0 && col < (COLS - 1)) {
					cell.addAdjacency(getCell(row, col - 1));
					cell.addAdjacency(getCell(row, col + 1));
				} else if (col == 0) { // otherwise, it is an edge
					cell.addAdjacency(getCell(row, col + 1));
				} else if (col == COLS - 1) { 
					cell.addAdjacency(getCell(row, col - 1));
				}
			}
		}		
	}
	
	/**
	 * Calculates the legal targets for a move from startCell of length pathLength
	 * @param startCell starting cell that we will move from
	 * @param pathlength length of a path
	 */
	public void calcTargets( TestBoardCell startCell, int pathlength) {
		Set<TestBoardCell> adjList = startCell.getAdjList();
		visited.add(startCell);
		//System.out.println("start: " + startCell);
		for(TestBoardCell adjCell : adjList) {
			if (!visited.contains(adjCell) && !adjCell.getOccupied() && !adjCell.isRoom()) {
				//System.out.println("adjCell: " + adjCell);
				visited.add(adjCell);
				if(pathlength == 1) {
					targets.add(adjCell);
				} else {
					calcTargets(adjCell, pathlength - 1);
				}
				visited.remove(adjCell);
			} 
		}
	}
	
	/**
	 * Returns the cell from the board at row, col
	 * @param row row of the cell
	 * @param col column of the cell
	 * @return
	 */
	public TestBoardCell getCell(int row, int col) {
		return grid[row][col];
	}
	
	/**
	 * Gets the targets last created by calcTargets()
	 * @return returns the targets last created by calcTargets()
	 */
	public Set<TestBoardCell> getTargets() {
		return targets;
	}
	
}
