package tests;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.Card;
import clueGame.CardType;
import clueGame.Player;
import clueGame.ComputerPlayer;
import clueGame.Solution;
import clueGame.Room;



public class ComputerAITest {
	private static Board board;
	private static ArrayList<Player> players;
	private static Solution suggestion;
	private static Player computerPlayer;
	private Map<Player, ArrayList<Card>> playerHands;
	private ArrayList<Card> computerHand;
	
	private static Card dagger;
	private static Card axe;
	private static Card wand;
	private static Card crossbow;
	private static Card trident;
	private static Card sword;
	private static Card hobbit;
	private static Card fairy;
	private static Card witch;
	private static Card mermaid;
	private static Card dragon;
	private static Card princess;
	private static Card mushroomHouse;
	private static Card fairyTree;
	private static Card waterfall;
	private static Card lilypad;
	private static Card hobbitHole;
	private static Card witchCave;
	
	@BeforeAll
	public static void setUp() {
		dagger = new Card("Dagger", CardType.WEAPON);
		axe = new Card("Axe", CardType.WEAPON);
		wand = new Card("Wand", CardType.WEAPON);
		crossbow = new Card("Crossbow", CardType.WEAPON);
		trident = new Card("Trident", CardType.WEAPON);
		sword = new Card("Sword", CardType.WEAPON);
		
		hobbit = new Card("Hobbit", CardType.CHARACTER);
		fairy = new Card("Fairy", CardType.CHARACTER);
		witch = new Card("Witch", CardType.CHARACTER);
		mermaid = new Card("Mermaid", CardType.CHARACTER);
		dragon = new Card("Dragon", CardType.CHARACTER);
		princess = new Card("Princess", CardType.CHARACTER);
		
    	mushroomHouse = new Card("MushroomHouse", CardType.ROOM);
    	fairyTree = new Card("FairyTree", CardType.ROOM);
    	waterfall = new Card("Waterfall", CardType.ROOM);
    	lilypad = new Card("LilypadPond", CardType.ROOM);
    	hobbitHole = new Card("HobbitHole", CardType.ROOM);
    	witchCave = new Card("WitchCave", CardType.ROOM);
	}
	
	@BeforeEach
	public void setUpEach() {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");		
		// Initialize will load config files 
		board.initialize();
		
		players = board.getPlayers();
		playerHands = board.getPlayerHands();
	}
	
	@Test
	public void testComputerSuggestion() {
		// Get computer player to test with
		ComputerPlayer computerPlayer = (ComputerPlayer) players.get(1);
		computerPlayer.clearHand();

		// Create hand for computerPlayer
		computerPlayer.addToHand(waterfall);
		computerPlayer.addToHand(wand);
		computerPlayer.addToHand(mermaid);
		
		// Get hand for computerPlayer
		ArrayList<Card> computerHand = computerPlayer.getHand();
		
		// Add cards that computerPlayer has seen
		computerPlayer.addSeen(hobbit);
		computerPlayer.addSeen(princess);
		computerPlayer.addSeen(sword);
		computerPlayer.addSeen(trident);
		
		// Get unseen cards, should have all cards that are not added above
		ArrayList<Card> unseen = computerPlayer.getUnseenCards();
		
		// Put the player in MushroomHouse
		int row = 3;
		int column = 2;
		computerPlayer.setLocation(row, column);
		BoardCell location =  board.getCell(row, column);
		Room room = location.getCellRoom();

		// Testing if the room card in suggestion matches the computer's current location
		String roomName = room.getName();
		suggestion = computerPlayer.createSuggestion(location);
		Card roomCard = suggestion.getRoom();
		assertTrue(roomName.equals(roomCard.getName()));

		// Variables that will store the weapon, character, and room in suggestion
		Card randomPerson = new Card();
		Card randomWeapon = new Card(); 
		
		int witchCount = 0;
		int crossbowCount = 0;
		
		// Checks if multiple weapons and people are not seen, then they are randomly selected
		// Checking that the character and weapon are chosen randomly
		for(int i = 0; i < 1000; i++) {
			// Calling create suggestion to create the suggestion
			suggestion = computerPlayer.createSuggestion(location);
			randomPerson = suggestion.getPerson();
			randomWeapon = suggestion.getWeapon();
			
			if(randomPerson.equals(witch)) {
				witchCount++;
			}
			
			if(randomWeapon.equals(crossbow)) {
				crossbowCount++;
			}
		}
		
		// Asserts that character and weapon are chosen randomly
		assertTrue(witchCount <= 400 && witchCount >= 200);
		assertTrue(crossbowCount <= 400 && crossbowCount >= 200);
		
		// Checks that the weapon and character from the suggestion are from unseen
		Boolean weapon = false;
		Boolean character = false;
		
		for(Card card: unseen) {
			if(card.equals(randomWeapon)) {
				weapon = true;
			}
			if(card.equals(randomPerson)) {
				character = true;
			}
		}
		assertTrue(weapon && character);
		
		// Checks that the suggested weapon and character are not in the hand
		for(Card card: computerHand) {
			assertFalse(card.equals(randomWeapon));
			assertFalse(card.equals(randomPerson));
		}
		
		// Check with only one weapon and character not seen or in hand
		computerPlayer.clearHand();
		
		computerPlayer.addToHand(hobbitHole);
		computerPlayer.addToHand(witchCave);
		computerPlayer.addToHand(waterfall);
		
		computerPlayer.addSeen(hobbit);
		computerPlayer.addSeen(princess);
		computerPlayer.addSeen(witch);
		computerPlayer.addSeen(dragon);
		computerPlayer.addSeen(mermaid);
		
		computerPlayer.addSeen(sword);
		computerPlayer.addSeen(trident);
		computerPlayer.addSeen(dagger);
		computerPlayer.addSeen(axe);
		computerPlayer.addSeen(crossbow);
		
		suggestion = computerPlayer.createSuggestion(location);
		
		assertTrue(suggestion.getWeapon().equals(wand));
		assertTrue(suggestion.getPerson().equals(fairy));
		assertTrue(roomName.equals(roomCard.getName()));
		

	}
	
	@Test
	public void testSelectTarget() {
		Set<BoardCell> targets;
		
		// Test to see if computer chooses randomly when can go into 2 rooms
		ComputerPlayer computerPlayer = (ComputerPlayer) players.get(1);
		computerPlayer.setLocation(5, 4);
		
		int row = computerPlayer.getRow();
		int column = computerPlayer.getColumn();
		BoardCell location =  board.getCell(row, column);
		board.calcTargets(location, 5);
		
		// get the target cells from this location with a roll of 5 away
		targets = board.getTargets();
		computerPlayer.clearHand();

		// Add cards that computerPlayer has seen
		computerPlayer.addSeen(witchCave);
		computerPlayer.addSeen(fairyTree);
		BoardCell witchCaveCell = board.getCell(31, 12);
		BoardCell fairyTreeCell = board.getCell(15, 21);
	
		// Get unseen cards, should have all cards that are not added above

		BoardCell chosenCell = board.getCell(0, 0);
		// the two rooms that we are able to go into
		BoardCell mushroomHouseCell = board.getCell(3, 2);
		BoardCell gazebo = board.getCell(2, 7);
		
		int mushroomCount = 0;
		int gazeboCount = 0;
		boolean unseen = true;
		
		for(int i = 0; i < 1000; i++) {
			chosenCell = computerPlayer.selectTarget(targets);
			assertTrue(chosenCell.equals(gazebo) || chosenCell.equals(mushroomHouseCell));
			
			
			if(chosenCell.equals(gazebo)) {
				gazeboCount++;
			} else if(chosenCell.equals(mushroomHouseCell)) {
				mushroomCount++;
			} else if(chosenCell.equals(witchCaveCell) || chosenCell.equals(fairyTreeCell)) {
				unseen = false;
			}
		}
		
		// Asserts that room moved into is not part of the seen list
		assertTrue(unseen);
		
		// Asserts random selection
		assertTrue(gazeboCount <= 600 && gazeboCount >= 400);
		assertTrue(mushroomCount <= 600 && mushroomCount >= 400);
		
		// Test to see if computer will go into room when only one room option
		board.calcTargets(location, 3);
		targets = board.getTargets();
		chosenCell = computerPlayer.selectTarget(targets);
		
		assertTrue(chosenCell.equals(mushroomHouseCell));
		
		// Test to see that computer will choose random target if no room available
		board.calcTargets(location, 1);
		
		targets = board.getTargets();
		
		BoardCell cell = board.getCell(4, 4);
		BoardCell cell1 = board.getCell(5, 5);
		BoardCell cell2 = board.getCell(6, 4);
		int cellCount = 0;
		boolean rightCell = true;
		
		for(int i = 0; i < 1000; i++) {
			chosenCell = computerPlayer.selectTarget(targets);
			if(!chosenCell.equals(cell) && !chosenCell.equals(cell1) && !chosenCell.equals(cell2)) {
				rightCell = false;
			}
			if(chosenCell.equals(cell)) {
				cellCount++;
			}
		}
		
		// Assert random and make sure it is one of the three cells
		assertTrue(cellCount <= 400 && cellCount >= 200);
		assertTrue(rightCell);
		
		
		// Tests if room is in the list and it has been seen, then select randomly
		computerPlayer.clearHand();
		computerPlayer.setLocation(3, 16); // Right outside the lilypad pond
		computerPlayer.addSeen(lilypad);

		location = board.getCell(3, 16);
		board.calcTargets(location, 1);
		targets = board.getTargets();

		cell = board.getCell(3, 19);
		cell1 = board.getCell(2, 16);
		cell2 = board.getCell(4, 16);

		int count1 = 0;
		int count2 = 0;
		int count3 = 0;
		
		for(int i = 0; i < 1000; i++) {
			chosenCell = computerPlayer.selectTarget(targets);
			if (chosenCell == cell) {
				count1++;
			}
			else if (chosenCell == cell1) {
				count2++;
			}
			else if (chosenCell == cell2) {
				count3++;
			}
		}

		assertTrue(count1 <= 400 && count1 >= 200);
		assertTrue(count2 <= 400 && count2 >= 200);
		assertTrue(count3 <= 400 && count3 >= 200);
		
		// Test if 2 rooms in target but only one room not seen
		location = board.getCell(5, 4);
		board.calcTargets(location, 5);
		
		// get the target cells from this location with a roll of 5 away
		targets = board.getTargets();
		computerPlayer.clearHand();

		// Add cards that computerPlayer has seen
		computerPlayer.addSeen(mushroomHouse);
		computerPlayer.addSeen(fairyTree);
	
		chosenCell = computerPlayer.selectTarget(targets);

		// the one rooms that we are able to go into
		assertTrue(chosenCell.equals(gazebo));		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
