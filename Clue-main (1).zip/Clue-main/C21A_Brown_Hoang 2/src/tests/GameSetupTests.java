package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;


import clueGame.Board;
import clueGame.BoardCell;
import clueGame.Player;
import clueGame.CardType;
import clueGame.Card;

public class GameSetupTests {

	// We make the Board static because we can load it one time and 
	// then do all the tests. 
	private static Board board;
	private static BoardCell boardCell;
	private static ArrayList<Player> players;
	private static ArrayList<Card> roomCards;
	private static ArrayList<Card> weaponCards;
	private static ArrayList<Card> playerCards;
	private static ArrayList<Card> deck;
	private static Card[] solution;
	private static Map<Player, ArrayList<Card>> playerHands;
	private static Card[] accusation;
	private static Player player1;
	private static Player player2;
	private static Player player3;
	
	@BeforeAll
	public static void setUp() {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");		
		// Initialize will load config files 
		board.initialize();
		players = board.getPlayers();
		roomCards = board.getRoomCards();
		weaponCards = board.getWeaponCards();
		playerCards = board.getPlayerCards();
		deck = board.getDeckCards();
		solution = board.getSolution();
		playerHands = board.getPlayerHands();
		accusation = board.getAccusation();
	}
	
	// Tests if we have correctly loaded in the players for our fantasy clue board
	@Test
	public void testLoadingPlayer() {
		assertEquals(6, board.getPlayers().size());
		
		Player player1 = players.get(0);
		Player player2 = players.get(1);
    	
		assertEquals("Hobbit", player1.getName());
		assertEquals("Green", player1.getColor()); 
		
		boardCell = board.getCell(9, 0);
		BoardCell location1 = board.getCell(player1.getRow(), player1.getColumn());
		assertEquals(boardCell, location1);

		assertEquals("Fairy", player2.getName());
		assertEquals("Pink", player2.getColor()); 
		
		boardCell = board.getCell(7, 23);
		BoardCell location2 = board.getCell(player2.getRow(), player2.getColumn());
		assertEquals(boardCell, location2);
	}
	
	// Tests if the room cards were initialized correctly
	@Test
	public void testRoomCards() {
		assertEquals(9, roomCards.size());
		
		Card pond = new Card("LilypadPond", CardType.ROOM);
		Card tree = new Card("FairyTree", CardType.ROOM);
		Card cave = new Card("WitchCave", CardType.ROOM);
		Card tower = new Card("Tower", CardType.ROOM);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(roomCards.contains(pond));
		assertTrue(roomCards.contains(tree));
		assertTrue(roomCards.contains(cave));
		assertTrue(roomCards.contains(tower));
		
		// test if all the room cards are labeled as ROOM
		for (Card room : roomCards) {
			assertEquals(CardType.ROOM, room.getCardType());
		}
	}
	
	// Test weapon cards' initialization
	@Test
	public void testWeaponCards() {
		assertEquals(6, weaponCards.size());
		
		Card axe = new Card("Axe", CardType.WEAPON);
		Card wand = new Card("Wand", CardType.WEAPON);
		Card trident = new Card("Trident", CardType.WEAPON);
		Card dagger = new Card("Dagger", CardType.WEAPON);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(weaponCards.contains(axe));
		assertTrue(weaponCards.contains(wand));
		assertTrue(weaponCards.contains(trident));
		assertTrue(weaponCards.contains(dagger));
		
		// test if all the weapon cards are labeled as WEAPON
		for (Card weapon : weaponCards) {
			assertEquals(CardType.WEAPON, weapon.getCardType());
		}
	}
	
	// Test player cards' initialization
	@Test
	public void testPlayerCards() {
		assertEquals(6, playerCards.size());
		
		Card hobbit = new Card("Hobbit", CardType.CHARACTER);
		Card fairy = new Card("Fairy", CardType.CHARACTER);
		Card mermaid = new Card("Mermaid", CardType.CHARACTER);
		Card princess = new Card("Princess", CardType.CHARACTER);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(playerCards.contains(hobbit));
		assertTrue(playerCards.contains(fairy));
		assertTrue(playerCards.contains(mermaid));
		assertTrue(playerCards.contains(princess));
		
		// test if all the player cards are labeled as CHARACTER
		for (Card player : playerCards) {
			assertEquals(CardType.CHARACTER, player.getCardType());
		}
	}
	
	// Test if the human player is correctly initialized
	@Test
	public void testHumanPlayer() {
		Player player1 = players.get(0);
		
		assertEquals("Human", player1.playerType());
		
		// make sure there'ss only 1 human player
		int count = 0;
		for (Player player : players) {
			if (player.playerType().equals("Human")) {
				count++;
			}
		}
		
		assertEquals(1, count);
	}
	
	// Test if the Computer players are correctly initialized
	@Test
	public void testComputerPlayers() {
		Player player2 = players.get(1);
		Player player3 = players.get(3);
		Player player4 = players.get(5);

		
		assertEquals("Computer", player2.playerType());
		assertEquals("Computer", player3.playerType());
		assertEquals("Computer", player4.playerType());
		
		// make sure there'ss only 1 human player
		int count = 0;
		for (Player player : players) {
			if (player.playerType().equals("Computer")) {
				count++;
			}
		}
		
		assertEquals(5, count);
	}
	
	// Test to check deck of cards is created and contains the cards from the given setup file
	@Test
	public void testDeckCards() {
		assertEquals(21, deck.size());		
		
		// test that these cards are in the deck
		Card hobbit = new Card("Hobbit", CardType.CHARACTER);
		Card fairy = new Card("Fairy", CardType.CHARACTER);
		Card mermaid = new Card("Mermaid", CardType.CHARACTER);
		Card princess = new Card("Princess", CardType.CHARACTER);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(playerCards.contains(hobbit));
		assertTrue(playerCards.contains(fairy));
		assertTrue(playerCards.contains(mermaid));
		assertTrue(playerCards.contains(princess));
		
		Card axe = new Card("Axe", CardType.WEAPON);
		Card wand = new Card("Wand", CardType.WEAPON);
		Card trident = new Card("Trident", CardType.WEAPON);
		Card dagger = new Card("Dagger", CardType.WEAPON);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(weaponCards.contains(axe));
		assertTrue(weaponCards.contains(wand));
		assertTrue(weaponCards.contains(trident));
		assertTrue(weaponCards.contains(dagger));
		
		Card pond = new Card("LilypadPond", CardType.ROOM);
		Card tree = new Card("FairyTree", CardType.ROOM);
		Card cave = new Card("WitchCave", CardType.ROOM);
		Card tower = new Card("Tower", CardType.ROOM);
		
		// test if these cards exists
		// this tests both the equals method and also whether the cards exist
		assertTrue(roomCards.contains(pond));
		assertTrue(roomCards.contains(tree));
		assertTrue(roomCards.contains(cave));
		assertTrue(roomCards.contains(tower));
	}
	
	// test the "solution" of the game being dealt
	@Test
	public void testSolution() {
		// it should only have 3 cards
		assertEquals(3, solution.length);	
		
		// the cards should be of type ROOM, CHARACTER, AND WEAPON
		assertEquals(solution[0].getCardType(), CardType.ROOM);
		assertEquals(solution[1].getCardType(), CardType.CHARACTER);
		assertEquals(solution[2].getCardType(), CardType.WEAPON);
	}
	
	// test the algorithm of dealing cards to players
	@Test
	public void testDealCards() {
		// each hand should have at least 3 cards
		for (Player player : playerHands.keySet()) {
			ArrayList<Card> currentHand = playerHands.get(player);
			assertTrue(currentHand.size() >= 3);
		}
	}
	
	//tests randomness of cards being drawn in the solution
	//@Test
    public void testRandomnessOfSolution() {
		// map to test certain cards and how many times they show up if solution is redealt
		Map<Card, Integer> solutionCardCount = new HashMap<>(); 
		Card axe = new Card("Axe", CardType.WEAPON);
    	Card hobbit = new Card("Hobbit", CardType.CHARACTER);
    	Card fairyTree = new Card("FairyTree", CardType.ROOM);

		solutionCardCount.put(axe, 0);
    	solutionCardCount.put(hobbit, 0);
    	solutionCardCount.put(fairyTree, 0);

		// redeal solution 1000 times
		for(int i = 0; i < 1000; i++) {
			// reinitialize the board every time to get a new solution
			board.initialize();
			Card[] currentSolution = board.getSolution();

			// count how many times axe, hobbit, and fairyTree are dealt in the solution
			for(Card card : currentSolution) {
				if(card.equals(axe)) {
					solutionCardCount.put(axe, solutionCardCount.get(axe) + 1);
				} else if(card.equals(hobbit)) {
					solutionCardCount.put(hobbit, solutionCardCount.get(hobbit) + 1);
				} else if(card.equals(fairyTree)) {
					solutionCardCount.put(fairyTree, solutionCardCount.get(fairyTree) + 1);
				}		
			}
		}
		
		// frequency of each card should be 1000 / # of each type
		int expectedFairyTreeFrequency = 1000 / 9; 
    	int expectedHobbitFrequency = 1000 / 6; 
    	int expectedAxeFrequency = 1000 / 6; 

		// upper and lower threshold to allow for a randomness error of 20%
		int FairyTreeThresholdLower = (int) (expectedFairyTreeFrequency * 0.8);
    	int FairyTreeThresholdUpper = (int) (expectedFairyTreeFrequency * 1.2);
    	int HobbitThresholdLower = (int) (expectedHobbitFrequency * 0.8);
    	int HobbitThresholdUpper = (int) (expectedHobbitFrequency * 1.2);
    	int AxeThresholdLower = (int) (expectedAxeFrequency * 0.8);
    	int AxeThresholdUpper = (int) (expectedAxeFrequency * 1.2);

		// check if the number of times axe, fairyTree, and hobbit are dealt in the solution follows a random trend
		assertTrue(solutionCardCount.get(axe) >= AxeThresholdLower && solutionCardCount.get(axe) <= AxeThresholdUpper);
		assertTrue(solutionCardCount.get(fairyTree) >= FairyTreeThresholdLower && solutionCardCount.get(fairyTree) <= FairyTreeThresholdUpper);
		assertTrue(solutionCardCount.get(hobbit) >= HobbitThresholdLower && solutionCardCount.get(hobbit) <= HobbitThresholdUpper);
	} 

	//tests randomness of cards being drawn in the solution
	//@Test
	public void testRandomnessOfPlayerHands () {
		Map<Card, Integer> playerHandCardCount = new HashMap<>();
		Card axe = new Card("Axe", CardType.WEAPON);
    	Card hobbit = new Card("Hobbit", CardType.CHARACTER);
    	Card fairyTree = new Card("FairyTree", CardType.ROOM);

		playerHandCardCount.put(axe, 0);
    	playerHandCardCount.put(hobbit, 0);
    	playerHandCardCount.put(fairyTree, 0);

		// redeal hand 1000 times
		for(int i = 0; i < 1000; i++) {
			// reinitialize the board every time to get a new hand
			board.initialize();
			Map<Player, ArrayList<Card>> playerHands = board.getPlayerHands();

			ArrayList<Player> playerList = new ArrayList<>(playerHands.keySet());

			ArrayList<Card> hand = playerHands.get(playerList.get(0));

			// count how many times axe, hobbit, and fairyTree are dealt in the hand
			for(Card card : hand) {
				if(card.equals(axe)) {
					playerHandCardCount.put(axe, playerHandCardCount.get(axe) + 1);
				} else if(card.equals(hobbit)) {
					playerHandCardCount.put(hobbit, playerHandCardCount.get(hobbit) + 1);
				} else if(card.equals(fairyTree)) {
					playerHandCardCount.put(fairyTree, playerHandCardCount.get(fairyTree) + 1);
				}
			}
		}

		// frequency of each card should be 1000 / 7 (drawing 3 cards from the deck is 3/21 probability, so 1/7)
		int expectedFrequency = 1000 / 7; 

		// upper and lower threshold to allow for a randomness error of 20%
		int ThresholdLower = (int) (expectedFrequency * 0.8);
    	int ThresholdUpper = (int) (expectedFrequency * 1.2);


		// check if the number of times axe, fairyTree, and hobbit are dealt in a hand follows a random trend
		assertTrue(playerHandCardCount.get(axe) >= ThresholdLower && playerHandCardCount.get(axe) <= ThresholdUpper);
		assertTrue(playerHandCardCount.get(fairyTree) >= ThresholdLower && playerHandCardCount.get(axe) <= ThresholdUpper);
		assertTrue(playerHandCardCount.get(hobbit) >= ThresholdLower && playerHandCardCount.get(axe) <= ThresholdUpper);
	}	
}

















