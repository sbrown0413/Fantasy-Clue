package tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.Card;
import clueGame.CardType;
import clueGame.Player;

public class GameSolutionTest {

	private static Board board;
	private static ArrayList<Player> players;
	private static Card[] solution;
	private static Card[] accusation;
	
	private static Card dagger;
	private static Card axe;
	private static Card wand;
	private static Card crossbow;
	private static Card trident;
	private static Card sword;
	private static Card hobbit;
	private static Card fairy;
	private static Card witch;
	private static Card mermaid;
	private static Card dragon;
	private static Card princess;
	private static Card mushroomHouse;
	private static Card fairyTree;
	private static Card waterfall;
	private static Card lilypad;
	private static Card hobbitHole;
	private static Card witchCave;
		
	@BeforeAll
	public static void setUp() {
		dagger = new Card("Dagger", CardType.WEAPON);
		axe = new Card("Axe", CardType.WEAPON);
		wand = new Card("Wand", CardType.WEAPON);
		crossbow = new Card("Crossbow", CardType.WEAPON);
		trident = new Card("Trident", CardType.WEAPON);
		sword = new Card("Sword", CardType.WEAPON);
		
		hobbit = new Card("Hobbit", CardType.CHARACTER);
		fairy = new Card("Fairy", CardType.CHARACTER);
		witch = new Card("Witch", CardType.CHARACTER);
		mermaid = new Card("Mermaid", CardType.CHARACTER);
		dragon = new Card("Dragon", CardType.CHARACTER);
		princess = new Card("Princess", CardType.CHARACTER);
		
    	mushroomHouse = new Card("MushroomHouse", CardType.ROOM);
    	fairyTree = new Card("FairyTree", CardType.ROOM);
    	waterfall = new Card("Waterfall", CardType.ROOM);
    	lilypad = new Card("LilypadPond", CardType.ROOM);
    	hobbitHole = new Card("HobbitHole", CardType.ROOM);
    	witchCave = new Card("WitchCave", CardType.ROOM);
	}
	
	@BeforeEach
	public void setUpEach() {
		// Board is singleton, get the only instance
		board = Board.getInstance();
		// set the file names to use my config files
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");		
		// Initialize will load config files 
		board.initialize();
		
		players = board.getPlayers();
		solution = board.getSolution();
		accusation = board.getAccusation();
	}
	
	// testing if our accusation method words
	@Test
	public void testDisproveAccusation() {
		Card axe = new Card("Axe", CardType.WEAPON);
    	Card hobbit = new Card("Hobbit", CardType.CHARACTER);
    	Card fairyTree = new Card("FairyTree", CardType.ROOM);
    	
    	solution = board.setSolution(axe, hobbit, fairyTree);
    	
    	Card dagger = new Card("Dagger", CardType.WEAPON);
    	Card dragon = new Card("Dragon", CardType.CHARACTER);
    	Card mushroomHouse = new Card("MushroomHouse", CardType.ROOM);
    	
		// check if we have an entirely incorrect accusation
    	board.makeAccusation(dagger, dragon, mushroomHouse);
    	accusation = board.getAccusation();
    	
    	assertFalse(board.checkAccusation());
    	
		// check if our accusation was correct
    	board.makeAccusation(axe, hobbit, fairyTree);
    	accusation = board.getAccusation();
    	
    	assertTrue(board.checkAccusation());
    	
		// check our accusation when only the room is wrong
    	board.makeAccusation(axe, hobbit, mushroomHouse);
    	accusation = board.getAccusation();
    	
    	assertFalse(board.checkAccusation());
    	
		// check our accusation when only the person is wrong
    	board.makeAccusation(axe, dragon, fairyTree);
    	accusation = board.getAccusation();
    	
    	assertFalse(board.checkAccusation());
    	
		// check our accusation when only the weapon is wrong
    	board.makeAccusation(dagger, hobbit, fairyTree);
    	accusation = board.getAccusation();
    	
    	assertFalse(board.checkAccusation());
	}
	
	// testing whether if a player has one of the cards in the suggestion that it returns that card
	// if there are no matching cards, return null
	@Test
	public void testDisproveSuggestion() {
		Player player1 = players.get(0);
		player1.clearHand();
		Player player2 = players.get(1);
		player2.clearHand();
		
		// Test Suggestion Cards
    	Card dagger = new Card("Dagger", CardType.WEAPON);
		Card dragon = new Card("Dragon", CardType.CHARACTER);
    	Card mushroomHouse = new Card("MushroomHouse", CardType.ROOM);
    	
    	player1.setSuggestion(dagger, dragon, mushroomHouse); 
		
    	Card witch = new Card("Witch", CardType.CHARACTER);
    	Card tower = new Card("Tower", CardType.ROOM);
		
		// Only one matching card in hand from suggestion
		player2.addToHand(dagger);
		player2.addToHand(witch);
		player2.addToHand(tower);
		
		Card cardOne = player2.disproveSuggestion(player1.getSuggestion());
		
		assertTrue(cardOne.equals(dagger));
		
		// No matching cards in hand from suggestion
		player2.clearHand();
		
		Card axe = new Card("Axe", CardType.WEAPON);
		
		player2.addToHand(axe);
		player2.addToHand(witch);
		player2.addToHand(tower);
		
		Card cardNull = player2.disproveSuggestion(player1.getSuggestion());
				
		assertTrue(cardNull == null);
		
		// Multiple matching cards in hand from suggestion which should be randomly chosen
		player2.clearHand();
		
		player2.addToHand(dagger);
		player2.addToHand(dragon);
		player2.addToHand(tower);
		
		int dragonCount = 0;
		int daggerCount = 0;
		// Testing randomness		
		for(int i = 0; i < 200; i++) {
			Card cardRandom = player2.disproveSuggestion(player1.getSuggestion());
			if(cardRandom.equals(dragon)) {
				dragonCount++;
			} else if(cardRandom.equals(dagger)) {
				daggerCount++;
			}
		}
		assertTrue(dragonCount <= 150 && dragonCount >= 50);
		assertTrue(daggerCount <= 150 && daggerCount >= 50);
	}
	
	// testing getting suggestions from 
	@Test
	public void testHandleSuggestion() {
		Player player1 = players.get(0);
		Player player2 = players.get(1);
		Player player3 = players.get(2);
		Player player4 = players.get(3);
		Player player5 = players.get(4);
		Player player6 = players.get(5);
		
		// clear the hands and add in our own cards for simulation
		player1.clearHand();
		player2.clearHand();
		player3.clearHand();
		player4.clearHand();
		player5.clearHand();
		player6.clearHand();
    	
		player1.addToHand(dagger);
		player1.addToHand(hobbit);
		player1.addToHand(witchCave);
		
		player2.addToHand(axe);
		player2.addToHand(fairyTree);
		
		player3.addToHand(wand);
		player3.addToHand(witch);
		player3.addToHand(waterfall);
		
		player4.addToHand(crossbow);
		player4.addToHand(lilypad);
		
		player5.addToHand(dragon);
		player5.addToHand(hobbitHole);
		
		player6.addToHand(sword);
		player6.addToHand(princess);
		
		// suggestion that will return null for all hands		
    	player1.setSuggestion(mushroomHouse, fairy, trident);
		Card disprove = board.handleSuggestion(player1.getSuggestion(), player1);
		
		assertTrue(disprove == null);
		
		// suggestion that will return null even though it is in the current player's hands 
		player1.setSuggestion(dagger, hobbit, witchCave);
		disprove = board.handleSuggestion(player1.getSuggestion(), player1);
		
		assertTrue(disprove == null);

		// suggestion that only the human can dsprove can disprove
		player2.setSuggestion(dagger, mermaid, lilypad);
		disprove = board.handleSuggestion(player2.getSuggestion(), player2);
		
		// suggestion where player 1 is accuser that player 2 and player 3 can disprove, but stops at player 2
		player1.setSuggestion(axe, witch, waterfall);
		disprove = board.handleSuggestion(player1.getSuggestion(), player1);
		// axe is the weapon held by player 1, so this is what it should reutrn
		assertTrue(disprove.equals(axe));
	}
}