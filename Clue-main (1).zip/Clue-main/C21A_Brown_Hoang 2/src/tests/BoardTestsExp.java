/**
 * BoardTestsExp -- unit testing for adjacency lists of each cell and target movement
 * Authors: Summer Brown and Kairi Hoang
 * Date: 10/7/24
 * Collaborators: None
 * Sources: C13A-2 Example Codes
 */
package tests;

import experiment.TestBoard;
import experiment.TestBoardCell;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

public class BoardTestsExp {
	
	TestBoard board;
	
	/*
	 * Creates board
	 * P.S. Used example code given as a guideline
	 */
	@BeforeEach // Run before each test, @BeforeAll would work just as well
	public void setUp() {
	    // board should create adjacency list
	    board = new TestBoard();
	}
	
	/*
     * Test adjacencies for the top left corner of the board
     * P.S. Used example code given as a guideline
     */
	@Test
    public void testAdjacencyTopLeft() {
        TestBoardCell cell = board.getCell(0, 0); //Top left corner cell
        Set<TestBoardCell> adjList = cell.getAdjList();
        //adjacent cells:
        assertTrue(adjList.contains(board.getCell(1, 0)));
        assertTrue(adjList.contains(board.getCell(0, 1)));
        assertEquals(2, adjList.size()); //Checks if number of adjacent cells is correct
    }
	
	/*
     * Test adjacencies for the bottom right corner of the board
     * P.S. Used example code given as a guideline
     */
    @Test
    public void testAdjacencyBottomRight() {
        TestBoardCell cell = board.getCell(3, 3); //Bottom right corner cell
        Set<TestBoardCell> adjList = cell.getAdjList();
        //adjacent cells:
        assertTrue(adjList.contains(board.getCell(3, 2)));
        assertTrue(adjList.contains(board.getCell(2, 3)));
        assertEquals(2, adjList.size()); //Checks if number of adjacent cells is correct

    }

    /*
     * Test adjacencies for the right edge of the board
     * P.S. Used example code given as a guideline
     */
    @Test
    public void testAdjacencyRightEdge() {
        TestBoardCell cell = board.getCell(1, 3); //Arbitrarily picked right edge cell
        Set<TestBoardCell> adjList = cell.getAdjList();
        //adjacent cells:
        assertTrue(adjList.contains(board.getCell(0, 3)));
        assertTrue(adjList.contains(board.getCell(2, 3)));
        assertTrue(adjList.contains(board.getCell(1, 2)));
        assertEquals(3, adjList.size()); //Checks if number of adjacent cells is correct
    }
    
    /*
     * Test adjacencies for the left edge of the board
     * P.S. Used example code given as a guideline
     */
    @Test
    public void testAdjacencyBottomLeftCorner() {
        TestBoardCell cell = board.getCell(3, 0); //Arbitrarily picked left edge cell
        Set<TestBoardCell> adjList = cell.getAdjList();
        //adjacent cells:
        assertTrue(adjList.contains(board.getCell(2, 0)));
        assertTrue(adjList.contains(board.getCell(3, 1)));
        assertEquals(2, adjList.size()); //Checks if number of adjacent cells is correct
    }
    
    /*
     * Test adjacencies for the middle of the board
     * P.S. Used example code given as a guideline
     */
    @Test
    public void testAdjacencyMiddle() {
        TestBoardCell cell = board.getCell(2, 2); //Arbitrarily picked middle cell
        Set<TestBoardCell> adjList = cell.getAdjList();
        assertEquals(4, adjList.size());
        //adjacent cells:
        assertTrue(adjList.contains(board.getCell(1, 2)));
        assertTrue(adjList.contains(board.getCell(3, 2)));
        assertTrue(adjList.contains(board.getCell(2, 1)));
        assertTrue(adjList.contains(board.getCell(2, 3)));
        assertEquals(4, adjList.size()); //Checks if number of adjacent cells is correct
    }
    
    /*
     * Test targets with a roll of one at (0, 0) on an empty board
     */
    @Test
    public void testTargetsNormalOneStep() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 1);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(2, targets.size());
    	assertTrue(targets.contains(board.getCell(1, 0)));
    	assertTrue(targets.contains(board.getCell(0, 1)));
    }
    
    /*
     * Test targets with a roll of two at (0, 0) on an empty board
     */
    @Test
    public void testTargetsNormalTwoSteps() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 2);
    	Set<TestBoardCell> targets = board.getTargets();
        
    	assertEquals(3, targets.size());
    	assertTrue(targets.contains(board.getCell(0, 2)));
    	assertTrue(targets.contains(board.getCell(2, 0)));
    	assertTrue(targets.contains(board.getCell(1, 1)));
    }
    
    /*
     * Test targets with a roll of three at (0, 0) on an empty board
     * From the example code in the assignment
     */
    @Test
    public void testTargetsNormalThreeSteps() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 3);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(6, targets.size());
    	assertTrue(targets.contains(board.getCell(3, 0)));
    	assertTrue(targets.contains(board.getCell(2, 1)));
    	assertTrue(targets.contains(board.getCell(0, 1)));
    	assertTrue(targets.contains(board.getCell(1, 2)));
    	assertTrue(targets.contains(board.getCell(0, 3)));
    	assertTrue(targets.contains(board.getCell(1, 0)));
    }
    
    /*
     * Test targets with a roll of four at (0, 0) on an empty board
     */
    @Test
    public void testTargetsNormalFourSteps() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 4);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(6, targets.size());
    	assertTrue(targets.contains(board.getCell(0, 2)));
    	assertTrue(targets.contains(board.getCell(1, 3)));
    	assertTrue(targets.contains(board.getCell(2, 0)));
    	assertTrue(targets.contains(board.getCell(1, 1)));
    	assertTrue(targets.contains(board.getCell(2, 2)));
    	assertTrue(targets.contains(board.getCell(3, 1)));
    }
    
    /*
     * Test targets with a roll of five at (0, 0) on an empty board
     */
    @Test
    public void testTargetsNormalFiveSteps() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 5);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(8, targets.size());
    	assertTrue(targets.contains(board.getCell(0, 1)));
    	assertTrue(targets.contains(board.getCell(0, 3)));
    	assertTrue(targets.contains(board.getCell(1, 0)));
    	assertTrue(targets.contains(board.getCell(1, 2)));
    	assertTrue(targets.contains(board.getCell(2, 1)));
    	assertTrue(targets.contains(board.getCell(2, 3)));
    	assertTrue(targets.contains(board.getCell(3, 0)));
    	assertTrue(targets.contains(board.getCell(3, 2)));
    }
    
    /*
     * Test targets with a roll of six at (0, 0) on an empty board
     */
    @Test
    public void testTargetsNormalSixSteps() {
    	TestBoardCell cell = board.getCell(0, 0);
    	board.calcTargets(cell, 6);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(7, targets.size());
    	assertTrue(targets.contains(board.getCell(0, 2)));
    	assertTrue(targets.contains(board.getCell(1, 1)));
    	assertTrue(targets.contains(board.getCell(1, 3)));
    	assertTrue(targets.contains(board.getCell(2, 0)));
    	assertTrue(targets.contains(board.getCell(2, 2)));
    	assertTrue(targets.contains(board.getCell(3, 1)));
    	assertTrue(targets.contains(board.getCell(3, 3)));
    }
    
    /*
     * Test targets with a roll of three at (1, 1) on an empty board
     */
    @Test
    public void testTargetsNormalThreeStepsMiddleBoard() {
    	TestBoardCell cell = board.getCell(1, 1);
    	board.calcTargets(cell, 3);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(8, targets.size());
    	assertTrue(targets.contains(board.getCell(0, 1)));
    	assertTrue(targets.contains(board.getCell(0, 3)));
    	assertTrue(targets.contains(board.getCell(1, 0)));
    	assertTrue(targets.contains(board.getCell(1, 2)));
    	assertTrue(targets.contains(board.getCell(2, 1)));
    	assertTrue(targets.contains(board.getCell(2, 3)));
    	assertTrue(targets.contains(board.getCell(3, 0)));
    	assertTrue(targets.contains(board.getCell(3, 2)));
    }
    
	/*
	 * Test target calculation when a room is present. A room stops movement.
	 */    
    @Test
    public void testTargetsWithRoom() {
        TestBoardCell room = board.getCell(1, 1); //defines room
        room.setRoom(true);

        board.calcTargets(board.getCell(0, 0), 3); 

        
        Set<TestBoardCell> targets = board.getTargets();

        
        assertFalse(targets.contains(room));
        assertEquals(4, targets.size());
    }
    
    /*
     * Test target calculation when a room is present and the player has extra moves.
     */
    @Test
    public void testTargetsWithRoomAndExtraMoves() {
        TestBoardCell roomCell = board.getCell(2, 2);
        roomCell.setRoom(true);

        board.calcTargets(board.getCell(0, 0), 5);

        Set<TestBoardCell> targets = board.getTargets();

        assertFalse(targets.contains(roomCell));
        assertEquals(8, targets.size()); 
    }

	
	/*
	 *  Test target calculation when a cell is occupied by another player.
	 */
    @Test
    public void testTargetsOccupiedCell() {
        TestBoardCell occupiedCell = board.getCell(1, 1);
        occupiedCell.setOccupied(true);

        board.calcTargets(board.getCell(0, 0), 3);

        Set<TestBoardCell> targets = board.getTargets();

        assertTrue(targets.contains(board.getCell(0, 3)));
        assertTrue(targets.contains(board.getCell(1, 2)));
        assertTrue(targets.contains(board.getCell(2, 1)));
        assertTrue(targets.contains(board.getCell(3, 0)));
        assertFalse(targets.contains(occupiedCell));
        assertEquals(4, targets.size());  
    }
    
    /*
     * Test target calculation when multiple cells are occupied by other players.
     */
    @Test
    public void testMultipleOccupiedCells() {
        TestBoardCell occupiedCell1 = board.getCell(1, 1);
        occupiedCell1.setOccupied(true);
        TestBoardCell occupiedCell2 = board.getCell(2, 0);
        occupiedCell2.setOccupied(true);

        board.calcTargets(board.getCell(0, 0), 4);

        Set<TestBoardCell> targets = board.getTargets();

        assertFalse(targets.contains(occupiedCell1));
        assertFalse(targets.contains(occupiedCell2));
        assertEquals(2, targets.size());  
    }

    /*
     * Test target with rooms and occupied cells
     * Starting on an edge and has the choice of going into a room, or walking outside, but cannot go past the occupied cell
     * From the example code in the assignment
     */
    @Test
    public void testTargetsMixedEdge() {
    	// occupied cells
    	board.getCell(0, 2).setOccupied(true);
    	board.getCell(1, 2).setRoom(true);
    	TestBoardCell cell = board.getCell(0, 3);
    	board.calcTargets(cell, 3);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(2, targets.size());
    	assertTrue(targets.contains(board.getCell(2, 2)));
    	assertTrue(targets.contains(board.getCell(3, 3)));
    }
	
    /*
     * Test target with rooms and occupied cells
     * Starting on in the middle and has the choice of going into a room, or walking outside, but cannot go past the occupied cell
     */
    @Test
    public void testTargetsMixedMiddle() {
    	// occupied cells
    	board.getCell(0, 2).setOccupied(true);
    	board.getCell(0, 1).setRoom(true);
    	TestBoardCell cell = board.getCell(0, 3);
    	board.calcTargets(cell, 2);
    	Set<TestBoardCell> targets = board.getTargets();
    	assertEquals(2, targets.size());
    	assertTrue(targets.contains(board.getCell(1, 2)));
    	assertTrue(targets.contains(board.getCell(2, 3)));
    }
}
